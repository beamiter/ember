//! One-command install and update for the companion shell, `jsh`.
//!
//! Every jterm prefers `jsh` over `bash` when it finds one on `PATH`, so a
//! machine without it silently runs the second choice. This module closes that
//! gap without teaching a terminal how to install software: the install logic
//! lives in the jsh repository, and the crate embeds a copy of that script and
//! runs it.
//!
//! Three consequences of that split are load-bearing:
//!   * The script is the only thing that touches the binary, so atomic
//!     replacement, checksum verification, rollback and the "something else on
//!     PATH is named jsh" case are handled in one place for all four terminals.
//!   * The update check reads the installer's own cache, which is shared
//!     across terminals, so several jterms open at once still make one network
//!     call per interval.
//!   * Nothing here draws anything. A frontend asks [`check_blocking`] what the
//!     situation is (off the UI thread), turns it into a [`Prompt`] with
//!     [`prompt_for`], and runs [`install_argv`] in a terminal tab of its own
//!     making.

use std::io::{self, Read};

use std::path::{Path, PathBuf};
use std::process::Stdio;
use std::thread;
use std::time::{Duration, Instant};

use serde::Deserialize;

/// Vendored from the jsh repository (`scripts/install-jsh.sh`). Embedding it
/// is what lets a machine with no `jsh` at all bootstrap one. Publishing it on
/// disk — privately, atomically, and only when the bytes changed — is
/// [`crate::vendored_script`]'s job, shared with the remote launcher.
const INSTALLER: crate::vendored_script::VendoredScript = crate::vendored_script::VendoredScript {
    name: "install-jsh.sh",
    source: include_str!("../scripts/install-jsh.sh"),
};
const MAX_CHECK_OUTPUT_BYTES: u64 = 64 * 1024;
const CHECK_PROCESS_TIMEOUT: Duration = Duration::from_secs(310);
const CHECK_PIPE_CLOSE_GRACE: Duration = Duration::from_millis(100);
const CHECK_POLL_INTERVAL: Duration = Duration::from_millis(10);
const MAX_VERSION_LABEL_BYTES: usize = 128;
const MAX_STATUS_ERROR_CHARS: usize = 512;
const MAX_STATUS_PATH_CHARS: usize = 4 * 1024;

/// Seconds a cached update check stays fresh for [`UpdateCheck::Daily`].
pub const DAILY_MAX_AGE: u64 = 86_400;

/// Keeps the tab open after the script finishes. Without it the child exits,
/// the terminal closes the tab, and the user never sees what happened.
///
/// The tab inherits the user's environment, but the tools the script executes
/// must not resolve from user-writable directories, so PATH is clamped to the
/// system ones. The pre-clamp PATH is what the user's own shells resolve `jsh`
/// from — usually `~/.cargo/bin` — so it is kept, for lookup only, in
/// `JSH_LOOKUP_PATH`: without it the installer cannot see an existing jsh
/// outside the default destination and would plant a second copy beside it.
const RUN_WRAPPER: &str = r#"set -f
JSH_LOOKUP_PATH=${PATH-}
export JSH_LOOKUP_PATH
PATH=/usr/bin:/bin
export PATH

/bin/sh "$1"
status=$?
printf '\n'
if [ "${status}" -eq 0 ]; then
    printf 'Done. Press Enter to close this tab.'
else
    printf 'install-jsh.sh exited %s. Press Enter to close this tab.' "${status}"
fi
read -r _
exit "${status}"
"#;

/// When to look for a newer jsh. The check never installs anything; it only
/// decides whether the offer appears.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum UpdateCheck {
    /// Ask the network on every launch.
    Startup,
    /// Reuse the installer's shared cache for a day. Several terminals open at
    /// once then still cost one request.
    #[default]
    Daily,
    Never,
}

impl UpdateCheck {
    pub fn as_str(self) -> &'static str {
        match self {
            UpdateCheck::Startup => "startup",
            UpdateCheck::Daily => "daily",
            UpdateCheck::Never => "never",
        }
    }

    pub fn parse(value: &str) -> UpdateCheck {
        if value.len() > 32
            || value.chars().any(char::is_control)
            || crate::review_input::contains_visual_spoofing(value)
        {
            return UpdateCheck::Daily;
        }
        match value.trim().to_ascii_lowercase().as_str() {
            "startup" | "launch" | "always" => UpdateCheck::Startup,
            "never" | "off" | "disabled" => UpdateCheck::Never,
            _ => UpdateCheck::Daily,
        }
    }

    /// Cache age to hand [`check_blocking`], or `None` when no check should run.
    pub fn max_age(self) -> Option<u64> {
        match self {
            UpdateCheck::Startup => Some(0),
            UpdateCheck::Daily => Some(DAILY_MAX_AGE),
            UpdateCheck::Never => None,
        }
    }
}

/// What `install-jsh.sh --check --json` reports.
#[derive(Debug, Clone, Default, Deserialize)]
#[serde(default)]
pub struct Status {
    /// Version of the jsh the terminal would manage, when one is installed.
    pub installed: Option<String>,
    pub installed_path: Option<String>,
    /// Newest published version, or `None` when the check could not reach it.
    pub latest: Option<String>,
    pub update_available: bool,
    /// Set when `PATH` resolves `jsh` to a binary that does not identify itself
    /// as this shell.
    pub shadowed_by: Option<String>,
    pub error: Option<String>,
}

impl Status {
    fn from_error(message: impl Into<String>) -> Self {
        Self {
            error: Some(bounded_visible_text(
                &message.into(),
                MAX_STATUS_ERROR_CHARS,
            )),
            ..Self::default()
        }
    }

    fn sanitize_untrusted_text(mut self) -> Self {
        self.installed_path = self
            .installed_path
            .map(|value| bounded_visible_text(&value, MAX_STATUS_PATH_CHARS));
        self.shadowed_by = self
            .shadowed_by
            .map(|value| bounded_visible_text(&value, MAX_STATUS_PATH_CHARS));
        self.error = self
            .error
            .map(|value| bounded_visible_text(&value, MAX_STATUS_ERROR_CHARS));
        self
    }
}

/// What is worth telling the user about, if anything.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Prompt {
    Missing { latest: String },
    Update { from: String, to: String },
}

impl Prompt {
    /// One line, already carrying this process's own name.
    pub fn banner_title(&self) -> String {
        match self {
            Prompt::Missing { latest } => format!(
                "{} prefers jsh as its shell — jsh {} is available",
                crate::identity::get().app_name,
                bounded_visible_text(latest, MAX_VERSION_LABEL_BYTES)
            ),
            Prompt::Update { from, to } => {
                format!(
                    "jsh {} is available — installed: {}",
                    bounded_visible_text(to, MAX_VERSION_LABEL_BYTES),
                    bounded_visible_text(from, MAX_VERSION_LABEL_BYTES)
                )
            }
        }
    }

    pub fn button_label(&self) -> &'static str {
        match self {
            Prompt::Missing { .. } => "Install",
            Prompt::Update { .. } => "Update",
        }
    }
}

/// Decide whether a check result deserves a prompt. A failed check is never
/// one: an offline laptop must not grow a bar it cannot act on.
///
/// `update_available` is necessary but not sufficient. The flag is computed by
/// the installer, and the installer that answered may be an older vendored copy
/// or a cache entry written by one — and until this round it set the flag on
/// mere string inequality, so a published release *older* than the installed
/// one (a yanked tag, or a source build that ran ahead of the last tag) arrived
/// here as an update. Ordering the versions here as well means a downgrade is
/// never labelled "Update" no matter which installer produced the answer.
pub fn prompt_for(status: &Status) -> Option<Prompt> {
    let latest = status.latest.clone()?;
    if !valid_version_label(&latest) {
        return None;
    }
    match status.installed.clone() {
        None => Some(Prompt::Missing { latest }),
        Some(installed)
            if valid_version_label(&installed)
                && status.update_available
                && version_gt(&latest, &installed) =>
        {
            Some(Prompt::Update {
                from: installed,
                to: latest,
            })
        }
        Some(_) => None,
    }
}

fn valid_version_label(value: &str) -> bool {
    !value.is_empty()
        && value.len() <= MAX_VERSION_LABEL_BYTES
        && value
            .bytes()
            .all(|byte| byte.is_ascii_alphanumeric() || matches!(byte, b'.' | b'-' | b'+' | b'_'))
}

fn bounded_visible_text(value: &str, max_chars: usize) -> String {
    value
        .chars()
        .map(|ch| {
            if ch.is_control() || crate::review_input::is_visual_spoofing_character(ch) {
                '\u{fffd}'
            } else {
                ch
            }
        })
        .take(max_chars)
        .collect()
}

/// Is `left` a strictly newer release than `right`?
///
/// The twin of `version_gt` in `scripts/install-jsh.sh` and deliberately as
/// blunt: compare `MAJOR.MINOR.PATCH` numerically, drop any pre-release suffix
/// rather than ordering it, and read an unparsable field as 0 so a version this
/// cannot understand sorts as older instead of being offered.
fn version_gt(left: &str, right: &str) -> bool {
    for index in 0..3 {
        let l = version_field(left, index);
        let r = version_field(right, index);
        if l != r {
            return l > r;
        }
    }
    false
}

/// One dotted field of a version, as a number; 0 when absent or unparsable.
fn version_field(version: &str, index: usize) -> u64 {
    version
        .strip_prefix('v')
        .unwrap_or(version)
        .split('-')
        .next()
        .unwrap_or_default()
        .split('.')
        .nth(index)
        .map(|field| {
            let digits: String = field.chars().take_while(char::is_ascii_digit).collect();
            digits.parse().unwrap_or(0)
        })
        .unwrap_or(0)
}

/// Materialize the embedded installer under the user's cache directory and
/// return its path. Rewritten only when the embedded copy changed, so the path
/// is stable across launches and shared by every terminal on the machine.
///
/// Under Flatpak this lands in the app's own cache directory, which is a real
/// directory in the user's home. The manifests carry `--filesystem=host`, so
/// the host-side `sh` that [`crate::host::command`] spawns sees the same path.
pub fn script_path() -> io::Result<PathBuf> {
    INSTALLER.path()
}

fn bounded_command_stdout(
    command: &mut std::process::Command,
    max_bytes: u64,
) -> io::Result<Vec<u8>> {
    let deadline = Instant::now() + CHECK_PROCESS_TIMEOUT;
    let mut child = crate::supervised::SupervisedChild::spawn(command)?;
    let Some(stdout) = child.take_stdout() else {
        return Err(io::Error::other("jsh installer check stdout was not piped"));
    };
    collect_bounded_command_stdout(child, stdout, max_bytes, deadline)
}

fn collect_bounded_command_stdout(
    mut child: crate::supervised::SupervisedChild,
    mut stdout: std::process::ChildStdout,
    max_bytes: u64,
    deadline: Instant,
) -> io::Result<Vec<u8>> {
    use std::os::fd::AsRawFd;

    let descriptor = stdout.as_raw_fd();
    // SAFETY: fcntl only reads/updates flags on the live pipe descriptor.
    let flags = unsafe { libc::fcntl(descriptor, libc::F_GETFL) };
    if flags < 0 || unsafe { libc::fcntl(descriptor, libc::F_SETFL, flags | libc::O_NONBLOCK) } < 0
    {
        return Err(io::Error::last_os_error());
    }

    let mut bytes = Vec::with_capacity(max_bytes.min(64 * 1024) as usize);
    let mut buffer = [0_u8; 8 * 1024];
    let mut root_exited_at = None;
    let mut eof = false;
    loop {
        loop {
            match stdout.read(&mut buffer) {
                Ok(0) => {
                    eof = true;
                    break;
                }
                Ok(count) => {
                    if bytes.len().saturating_add(count) > max_bytes as usize {
                        return Err(io::Error::new(
                            io::ErrorKind::FileTooLarge,
                            "jsh installer check output is too large",
                        ));
                    }
                    bytes.extend_from_slice(&buffer[..count]);
                }
                Err(error) if error.kind() == io::ErrorKind::Interrupted => continue,
                Err(error) if error.kind() == io::ErrorKind::WouldBlock => break,
                Err(error) => return Err(error),
            }
        }
        if root_exited_at.is_none() && child.root_has_exited()? {
            // Close the race where the root exits after the read above
            // returned WouldBlock. With the root now known dead, another
            // nonblocking drain distinguishes ordinary EOF from an
            // inherited writer before the group is cleared and reaped.
            if !eof {
                loop {
                    match stdout.read(&mut buffer) {
                        Ok(0) => {
                            eof = true;
                            break;
                        }
                        Ok(count) => {
                            if bytes.len().saturating_add(count) > max_bytes as usize {
                                return Err(io::Error::new(
                                    io::ErrorKind::FileTooLarge,
                                    "jsh installer check output is too large",
                                ));
                            }
                            bytes.extend_from_slice(&buffer[..count]);
                        }
                        Err(error) if error.kind() == io::ErrorKind::Interrupted => continue,
                        Err(error) if error.kind() == io::ErrorKind::WouldBlock => break,
                        Err(error) => return Err(error),
                    }
                }
            }
            root_exited_at = Some(Instant::now());
        }
        if eof && root_exited_at.is_some() {
            child.reap_after_group_kill()?;
            // A non-zero exit still carries the installer's structured error
            // body, so callers parse bytes independently of status.
            return Ok(bytes);
        }
        if root_exited_at.is_some_and(|exited| exited.elapsed() >= CHECK_PIPE_CLOSE_GRACE) {
            child.reap_after_group_kill()?;
            return Err(io::Error::new(
                io::ErrorKind::BrokenPipe,
                "jsh installer exited while a descendant kept stdout open",
            ));
        }
        if Instant::now() >= deadline {
            return Err(io::Error::new(
                io::ErrorKind::TimedOut,
                "jsh installer check timed out",
            ));
        }
        thread::sleep(CHECK_POLL_INTERVAL);
    }
}

/// Ask the installer what is installed and what is published. Blocking: call it
/// from a worker thread, never from a UI event loop.
///
/// `max_age` is handed to the installer's shared cache; 0 always goes to the
/// network.
pub fn check_blocking(max_age: u64) -> Status {
    let script = match script_path() {
        Ok(path) => path,
        Err(error) => return Status::from_error(format!("cannot write install-jsh.sh: {error}")),
    };

    let mut command = match crate::host::helper_command("sh") {
        Ok(command) => command,
        Err(error) => return Status::from_error(format!("cannot find sh: {error}")),
    };
    command
        .arg(&script)
        .arg("--check")
        .arg("--json")
        .arg("--max-age")
        .arg(max_age.to_string())
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::null());
    // The helper runs with PATH clamped to system directories, which also
    // starved the script's jsh detection: the jsh the user runs usually lives
    // in `~/.cargo/bin`, so every check reported "nothing installed" and the
    // install banner never went away. Hand this process's own PATH over for
    // lookup only — the script executes nothing resolved through it except
    // jsh itself, which this process already executes as the session shell.
    // (Under Flatpak the host-side launcher captures the host PATH instead;
    // an env var set here stops at flatpak-spawn.)
    if let Some(path) = std::env::var_os("PATH") {
        command.env("JSH_LOOKUP_PATH", path);
    }

    match bounded_command_stdout(&mut command, MAX_CHECK_OUTPUT_BYTES) {
        Ok(output) => {
            let text = String::from_utf8_lossy(&output);
            serde_json::from_str::<Status>(text.trim())
                .map(Status::sanitize_untrusted_text)
                .unwrap_or_else(|error| Status::from_error(format!("unreadable check: {error}")))
        }
        Err(error) => Status::from_error(format!("cannot run install-jsh.sh: {error}")),
    }
}

/// argv for the tab that performs the install. The script prints what it is
/// doing, so the tab itself is the progress UI.
///
/// Frontends should launch this the same way they launch any other command,
/// which on Flatpak means passing it through [`crate::host::wrap_argv`].
pub fn install_argv() -> io::Result<Vec<String>> {
    let script = script_path()?;
    Ok(install_argv_for(&script))
}

fn install_argv_for(script: &Path) -> Vec<String> {
    vec![
        "/bin/sh".to_string(),
        "-c".to_string(),
        RUN_WRAPPER.to_string(),
        "jterm-jsh-install".to_string(),
        script.to_string_lossy().into_owned(),
    ]
}

#[cfg(test)]
mod tests {
    use super::*;
    // Only the tests inspect modes and ownership now; publication itself moved
    // to `crate::vendored_script`.
    use std::os::unix::fs::PermissionsExt;

    fn status_from(json: &str) -> Status {
        serde_json::from_str(json).expect("valid check output")
    }

    #[test]
    fn vendored_installer_still_looks_like_the_script_we_call() {
        assert!(INSTALLER.source.starts_with("#!/bin/sh"));
        assert!(INSTALLER.source.contains("--check"));
        assert!(INSTALLER.source.contains("--max-age"));
        assert!(INSTALLER.source.contains("\"update_available\""));
    }

    #[cfg(unix)]
    #[test]
    fn cached_installer_is_private_bounded_and_replaces_hostile_entries() {
        use std::ffi::CString;
        use std::os::unix::ffi::OsStrExt;
        use std::os::unix::fs::symlink;

        static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
        let id = NEXT.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        let dir = std::env::temp_dir().join(format!(
            "jterm-core-jsh-installer-{}-{id}",
            std::process::id()
        ));
        let path = INSTALLER.materialize(&dir).unwrap();
        assert_eq!(std::fs::read(&path).unwrap(), INSTALLER.source.as_bytes());
        assert_eq!(
            std::fs::metadata(&dir).unwrap().permissions().mode() & 0o777,
            0o700
        );
        assert_eq!(
            std::fs::metadata(&path).unwrap().permissions().mode() & 0o777,
            0o700
        );

        let victim = dir.join("victim");
        std::fs::write(&victim, b"leave me").unwrap();
        std::fs::remove_file(&path).unwrap();
        symlink(&victim, &path).unwrap();
        INSTALLER.materialize(&dir).unwrap();
        assert_eq!(std::fs::read(&victim).unwrap(), b"leave me");
        assert_eq!(std::fs::read(&path).unwrap(), INSTALLER.source.as_bytes());

        std::fs::remove_file(&path).unwrap();
        std::fs::hard_link(&victim, &path).unwrap();
        INSTALLER.materialize(&dir).unwrap();
        assert_eq!(std::fs::read(&victim).unwrap(), b"leave me");
        assert_eq!(std::fs::read(&path).unwrap(), INSTALLER.source.as_bytes());

        std::fs::remove_file(&path).unwrap();
        let encoded = CString::new(path.as_os_str().as_bytes()).unwrap();
        // SAFETY: encoded is a live NUL-terminated path and the mode is valid.
        assert_eq!(unsafe { libc::mkfifo(encoded.as_ptr(), 0o600) }, 0);
        INSTALLER.materialize(&dir).unwrap();
        assert_eq!(std::fs::read(&path).unwrap(), INSTALLER.source.as_bytes());

        std::fs::write(&path, vec![b'x'; INSTALLER.source.len() + 1]).unwrap();
        INSTALLER.materialize(&dir).unwrap();
        assert_eq!(std::fs::read(&path).unwrap(), INSTALLER.source.as_bytes());
        assert!(std::fs::read_dir(&dir).unwrap().all(|entry| !entry
            .unwrap()
            .file_name()
            .to_string_lossy()
            .contains(".tmp.")));
        std::fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn installer_check_stdout_is_bounded_before_json_parsing() {
        fn run(script: &str, max_bytes: u64) -> (io::Result<Vec<u8>>, i32) {
            let mut command = std::process::Command::new("sh");
            command
                .args(["-c", script])
                .stdout(Stdio::piped())
                .stderr(Stdio::null());
            let mut child = crate::supervised::SupervisedChild::spawn(&mut command).unwrap();
            let pid = child.id() as i32;
            let stdout = child.take_stdout().unwrap();
            (
                collect_bounded_command_stdout(
                    child,
                    stdout,
                    max_bytes,
                    Instant::now() + CHECK_PROCESS_TIMEOUT,
                ),
                pid,
            )
        }

        fn assert_reaped(pid: i32) {
            let mut status = 0;
            // SAFETY: status is writable and the collector owned this child.
            assert_eq!(
                unsafe { libc::waitpid(pid, &mut status, libc::WNOHANG) },
                -1
            );
            assert_eq!(
                io::Error::last_os_error().raw_os_error(),
                Some(libc::ECHILD)
            );
        }

        let (exact, exact_pid) = run("printf test", 4);
        assert_eq!(exact.unwrap(), b"test");
        assert_reaped(exact_pid);

        let (oversized, oversized_pid) = run("printf tests", 4);
        assert_eq!(oversized.unwrap_err().kind(), io::ErrorKind::FileTooLarge);
        assert_reaped(oversized_pid);

        let started = Instant::now();
        let (inherited_pipe, inherited_pid) = run("sleep 5 &", 4);
        assert_eq!(
            inherited_pipe.unwrap_err().kind(),
            io::ErrorKind::BrokenPipe
        );
        assert_reaped(inherited_pid);
        assert!(started.elapsed() < Duration::from_secs(2));
    }

    /// This copy is vendored by hand from the jsh repository, so nothing forces
    /// it to be current — and a stale copy is not inert: it is what computes
    /// `update_available` and what actually installs. Assert on the behaviour
    /// that was wrong, so re-vendoring an older script fails here instead of
    /// silently reintroducing a downgrade offer.
    #[test]
    fn the_vendored_installer_orders_versions_rather_than_comparing_strings() {
        assert!(
            INSTALLER.source.contains("version_gt()"),
            "vendored install-jsh.sh predates the version-ordering fix; re-vendor it \
             from the jsh repository"
        );
        assert!(INSTALLER
            .source
            .contains("version_gt \"$1\" \"${installed_version}\""));
        // And the install path refuses to walk backwards on a bare run.
        assert!(INSTALLER.source.contains("is newer than the published"));
    }

    /// Same seam as the version-ordering canary. The check runs with PATH
    /// clamped to system directories, so the script must honour the
    /// `JSH_LOOKUP_PATH` override or a jsh living in `~/.cargo/bin` reports as
    /// "nothing installed" and the install banner never goes away.
    #[test]
    fn the_vendored_installer_honours_the_lookup_path_override() {
        assert!(
            INSTALLER.source.contains("JSH_LOOKUP_PATH"),
            "vendored install-jsh.sh predates the lookup-path override; re-vendor it \
             from the jsh repository"
        );
    }

    #[test]
    fn update_check_policies_round_trip_and_map_to_cache_ages() {
        for policy in [UpdateCheck::Startup, UpdateCheck::Daily, UpdateCheck::Never] {
            assert_eq!(UpdateCheck::parse(policy.as_str()), policy);
        }
        assert_eq!(UpdateCheck::parse("  NEVER "), UpdateCheck::Never);
        // Unknown values fall back to the conservative default rather than
        // disabling the check silently.
        assert_eq!(UpdateCheck::parse("weekly"), UpdateCheck::Daily);
        assert_eq!(UpdateCheck::Startup.max_age(), Some(0));
        assert_eq!(UpdateCheck::Daily.max_age(), Some(DAILY_MAX_AGE));
        assert_eq!(UpdateCheck::Never.max_age(), None);
        assert_eq!(UpdateCheck::parse(&"x".repeat(1_000)), UpdateCheck::Daily);
    }

    #[test]
    fn a_missing_jsh_is_offered_for_install() {
        let status = status_from(
            r#"{"schema":1,"installed":null,"installed_path":null,"latest":"0.3.0",
                "target":"x86_64-unknown-linux-gnu","update_available":true,
                "shadowed_by":"/usr/bin/jsh","error":null}"#,
        );
        assert_eq!(
            prompt_for(&status),
            Some(Prompt::Missing {
                latest: "0.3.0".into()
            })
        );
        assert_eq!(prompt_for(&status).unwrap().button_label(), "Install");
    }

    #[test]
    fn an_outdated_jsh_is_offered_for_update() {
        let status = status_from(
            r#"{"installed":"0.2.0","installed_path":"/home/u/.local/bin/jsh",
                "latest":"0.3.0","update_available":true}"#,
        );
        assert_eq!(
            prompt_for(&status),
            Some(Prompt::Update {
                from: "0.2.0".into(),
                to: "0.3.0".into()
            })
        );
    }

    #[test]
    fn a_current_install_says_nothing() {
        let status =
            status_from(r#"{"installed":"0.3.0","latest":"0.3.0","update_available":false}"#);
        assert_eq!(prompt_for(&status), None);
    }

    /// A published release older than the installed one is not an update, even
    /// when the answering installer insists it is. Reachable from a yanked tag,
    /// from a build made from source that ran ahead of the last tag, and from a
    /// cache entry written by a pre-fix installer — which set the flag whenever
    /// the two version strings merely differed.
    #[test]
    fn an_older_published_release_is_never_offered_as_an_update() {
        let status =
            status_from(r#"{"installed":"0.4.0","latest":"0.3.9","update_available":true}"#);
        assert_eq!(prompt_for(&status), None);
    }

    /// Versions order numerically, not as text: `0.10.0` is newer than `0.9.0`
    /// though it sorts below it as a string.
    #[test]
    fn versions_order_numerically() {
        assert!(version_gt("0.10.0", "0.9.0"));
        assert!(!version_gt("0.9.0", "0.10.0"));
        assert!(version_gt("1.0.0", "0.99.99"));
        assert!(version_gt("0.3.1", "0.3.0"));
        assert!(!version_gt("0.3.0", "0.3.0"));
        assert!(version_gt("v0.4.0", "0.3.0"));

        // A pre-release suffix is dropped rather than ordered: neither side wins,
        // so nothing is offered. Ordering them needs the full semver rule.
        assert!(!version_gt("0.3.0-rc1", "0.3.0"));
        assert!(!version_gt("0.3.0", "0.3.0-rc1"));

        // Unparsable reads as 0, so a version this cannot understand sorts as
        // older and is never offered over a real one.
        assert!(!version_gt("garbage", "0.1.0"));
        assert!(version_gt("0.1.0", "garbage"));
        assert!(!version_gt("", ""));

        // Missing trailing fields are zero, not an error.
        assert!(version_gt("0.4", "0.3.9"));
        assert!(!version_gt("0.3", "0.3.0"));
    }

    /// The prompt still fires for a genuine newer release whose ordering is only
    /// visible numerically — the case a lexicographic guard would have blocked.
    #[test]
    fn a_numerically_newer_release_is_still_offered() {
        let status =
            status_from(r#"{"installed":"0.9.0","latest":"0.10.0","update_available":true}"#);
        assert_eq!(
            prompt_for(&status),
            Some(Prompt::Update {
                from: "0.9.0".into(),
                to: "0.10.0".into()
            })
        );
    }

    #[test]
    fn an_unreachable_check_says_nothing() {
        // No prompt the user cannot act on, even though nothing is installed.
        let status = status_from(
            r#"{"installed":null,"latest":null,"update_available":false,
                "error":"cannot reach https://github.com/beamiter/jsh/releases"}"#,
        );
        assert_eq!(prompt_for(&status), None);
        assert!(status.error.is_some());
    }

    #[test]
    fn installer_status_text_cannot_inject_log_lines_or_grow_without_bound() {
        let status = Status {
            installed_path: Some(format!("/tmp/jsh\nforged{}", "x".repeat(8 * 1024))),
            shadowed_by: Some("evil\u{202e}txt\rnext".into()),
            error: Some(format!("offline\nforged{}", "x".repeat(2 * 1024))),
            ..Status::default()
        }
        .sanitize_untrusted_text();

        for value in [
            status.installed_path.as_deref().unwrap(),
            status.shadowed_by.as_deref().unwrap(),
            status.error.as_deref().unwrap(),
        ] {
            assert!(!value.chars().any(char::is_control));
            assert!(!crate::review_input::contains_visual_spoofing(value));
        }
        assert_eq!(
            status.installed_path.unwrap().chars().count(),
            MAX_STATUS_PATH_CHARS
        );
        assert_eq!(
            status.error.unwrap().chars().count(),
            MAX_STATUS_ERROR_CHARS
        );
    }

    #[test]
    fn unknown_fields_and_missing_fields_are_tolerated() {
        // The installer may grow fields; an older terminal must keep working.
        let status = status_from(r#"{"latest":"9.9.9","future_field":{"a":1}}"#);
        assert_eq!(
            prompt_for(&status),
            Some(Prompt::Missing {
                latest: "9.9.9".into()
            })
        );
    }

    #[test]
    fn release_labels_cannot_spoof_the_install_banner() {
        for latest in [
            "0.3.0\nforged",
            "0.3.0\u{202e}txt",
            "0.3.0\u{00a0}hidden",
            &"x".repeat(MAX_VERSION_LABEL_BYTES + 1),
        ] {
            let status = Status {
                latest: Some(latest.to_string()),
                update_available: true,
                ..Status::default()
            };
            assert!(prompt_for(&status).is_none(), "{latest:?}");
        }

        // The enum remains public for frontend state, so its rendering sink
        // repeats the sanitisation even for a directly constructed value.
        let title = Prompt::Missing {
            latest: "0.3.0\u{202e}forged".into(),
        }
        .banner_title();
        assert!(!title.contains('\u{202e}'));
        assert!(title.contains('\u{fffd}'));
    }

    #[test]
    fn the_install_tab_waits_for_the_user_before_closing() {
        assert!(RUN_WRAPPER.contains("read -r _"));
        assert!(RUN_WRAPPER.contains("exit \"${status}\""));
        assert!(RUN_WRAPPER.contains("PATH=/usr/bin:/bin"));
        assert!(RUN_WRAPPER.contains("/bin/sh \"$1\""));
        // The user's PATH is captured for jsh lookup before the clamp takes it
        // away; the other order captures the clamp.
        let capture = RUN_WRAPPER
            .find("JSH_LOOKUP_PATH=${PATH-}")
            .expect("wrapper keeps the pre-clamp PATH for jsh lookup");
        assert!(capture < RUN_WRAPPER.find("PATH=/usr/bin:/bin").unwrap());
        let argv = install_argv_for(Path::new("/tmp/install-jsh.sh"));
        assert_eq!(argv[0], "/bin/sh");
        assert_eq!(argv.last().map(String::as_str), Some("/tmp/install-jsh.sh"));
    }

    /// Local release metadata is signed with a fresh, unencrypted test key so
    /// these contracts exercise the real verifier without a production secret.
    struct SignedRelease {
        root: PathBuf,
        public_key: String,
    }

    impl Drop for SignedRelease {
        fn drop(&mut self) {
            let _ = std::fs::remove_dir_all(&self.root);
        }
    }

    impl SignedRelease {
        fn new() -> Option<Self> {
            use std::process::Command;

            // file:// fixtures need curl (wget does not support that scheme).
            let mut tool_paths = Vec::new();
            for tool in ["curl", "minisign"] {
                let output = Command::new("/bin/sh")
                    .args(["-c", "command -v \"$1\"", "sh", tool])
                    .output()
                    .expect("locate installer test prerequisite");
                if !output.status.success() {
                    eprintln!(
                        "skipped: {tool} is unavailable (required for signed release fixtures)"
                    );
                    return None;
                }
                let path = PathBuf::from(String::from_utf8(output.stdout).unwrap().trim());
                tool_paths.push(std::fs::canonicalize(path).expect("absolute tool path"));
            }

            let root =
                std::env::temp_dir().join(format!("jterm-jsh-contract-{}", uuid::Uuid::new_v4()));
            std::fs::create_dir(&root).expect("private fixture root");
            let mut fixture = Self {
                root,
                public_key: String::new(),
            };
            std::fs::set_permissions(&fixture.root, std::fs::Permissions::from_mode(0o700))
                .expect("private fixture permissions");
            for dir in ["release/latest/download", "home", "helpers"] {
                std::fs::create_dir_all(fixture.root.join(dir)).expect("fixture directory");
            }
            for (tool, path) in ["curl", "minisign"].into_iter().zip(&tool_paths) {
                std::os::unix::fs::symlink(path, fixture.root.join("helpers").join(tool))
                    .expect("fixture tool link");
            }
            let public_key_path = fixture.root.join("test.pub");
            let secret_key_path = fixture.root.join("test.key");
            let generated = Command::new(&tool_paths[1])
                .args(["-G", "-W", "-p"])
                .arg(&public_key_path)
                .arg("-s")
                .arg(&secret_key_path)
                .output()
                .expect("generate ephemeral minisign key");
            assert!(
                generated.status.success(),
                "minisign key generation: {}",
                String::from_utf8_lossy(&generated.stderr)
            );
            fixture.public_key = std::fs::read_to_string(public_key_path)
                .expect("public key")
                .lines()
                .nth(1)
                .expect("minisign public key data")
                .to_owned();
            std::fs::write(
                fixture.manifest(),
                r#"{"schema":1,"name":"jsh","version":"9.9.9","tag":"v9.9.9","artifacts":[]}"#,
            )
            .expect("manifest");
            let signed = Command::new(&tool_paths[1])
                .arg("-Sm")
                .arg(fixture.manifest())
                .arg("-s")
                .arg(&secret_key_path)
                .output()
                .expect("sign release manifest");
            assert!(
                signed.status.success(),
                "minisign signing: {}",
                String::from_utf8_lossy(&signed.stderr)
            );
            std::fs::write(fixture.root.join(INSTALLER.name), INSTALLER.source)
                .expect("embedded installer");
            Some(fixture)
        }

        fn manifest(&self) -> PathBuf {
            self.root.join("release/latest/download/manifest.json")
        }

        fn command(&self) -> std::process::Command {
            let home = self.root.join("home");
            // Allow only system tools plus the explicit test prerequisites.
            // In particular, the user's cargo bin is never an execution PATH.
            let path = format!("{}:/usr/bin:/bin", self.root.join("helpers").display());
            let mut command = std::process::Command::new("/bin/sh");
            command
                .arg(self.root.join(INSTALLER.name))
                .args(["--check", "--json", "--max-age", "0"])
                .env("HOME", &home)
                .env("XDG_CACHE_HOME", home.join("cache"))
                .env("XDG_STATE_HOME", home.join("state"))
                .env(
                    "JSH_INSTALL_BASE_URL",
                    format!("file://{}", self.root.join("release").display()),
                )
                .env("JSH_MINISIGN_PUBKEY", &self.public_key)
                .env("PATH", &path)
                .env("JSH_LOOKUP_PATH", &path);
            command
        }

        fn parse(output: &std::process::Output) -> Status {
            let stdout = String::from_utf8_lossy(&output.stdout);
            serde_json::from_str(stdout.trim()).unwrap_or_else(|error| {
                panic!(
                    "unparseable check output {stdout:?}: {error}; stderr: {}",
                    String::from_utf8_lossy(&output.stderr)
                )
            })
        }
    }

    /// The riskiest seam is the JSON contract: the installer lives in another
    /// repository and can be re-vendored at any time. Run the embedded script
    /// for real against a signed local release tree and parse what it prints
    /// with the same type the terminals use.
    #[test]
    fn the_embedded_script_emits_json_this_module_understands() {
        let Some(fixture) = SignedRelease::new() else {
            return;
        };

        // Whatever this machine has on PATH, the check must see the same thing:
        // a `jsh` that fails identification.
        let stub_bin = fixture.root.join("bin");
        std::fs::create_dir(&stub_bin).expect("stub bin");
        let stub_jsh = stub_bin.join("jsh");
        std::fs::write(&stub_jsh, "#!/bin/sh\nexit 1\n").expect("stub jsh");
        std::fs::set_permissions(&stub_jsh, std::fs::Permissions::from_mode(0o755)).expect("mode");
        let output = fixture
            .command()
            .env("JSH_LOOKUP_PATH", &stub_bin)
            .output()
            .expect("run install-jsh.sh --check");
        let status = SignedRelease::parse(&output);

        assert!(output.status.success(), "{:?}", status.error);
        assert_eq!(status.latest.as_deref(), Some("9.9.9"));
        assert_eq!(status.installed, None);
        assert_eq!(status.error, None);
        assert_eq!(
            status.shadowed_by.as_deref(),
            Some(&*stub_jsh.to_string_lossy())
        );
        assert_eq!(
            prompt_for(&status),
            Some(Prompt::Missing {
                latest: "9.9.9".into()
            })
        );
    }

    /// The regression that motivated `JSH_LOOKUP_PATH`, end to end: PATH
    /// clamped to system directories and explicit verification tools, a genuine
    /// jsh outside them (`~/.cargo/bin` is the common home), and the user's real
    /// PATH passed for lookup only. A current shell should raise no banner.
    #[test]
    fn a_clamped_check_still_finds_the_users_jsh_through_the_lookup_path() {
        let Some(fixture) = SignedRelease::new() else {
            return;
        };
        let cargo_bin = fixture.root.join("home/.cargo/bin");
        std::fs::create_dir_all(&cargo_bin).expect("cargo bin");
        let jsh = cargo_bin.join("jsh");
        std::fs::write(
            &jsh,
            "#!/bin/sh\n[ \"$1\" = --version ] && echo 'jsh 9.9.9 (fake)'\nexit 0\n",
        )
        .expect("stub jsh");
        std::fs::set_permissions(&jsh, std::fs::Permissions::from_mode(0o755)).expect("mode");

        let output = fixture
            .command()
            .env(
                "JSH_LOOKUP_PATH",
                format!("{}:/usr/bin:/bin", cargo_bin.display()),
            )
            .output()
            .expect("run install-jsh.sh --check");
        let status = SignedRelease::parse(&output);

        assert!(output.status.success(), "{:?}", status.error);
        assert_eq!(status.error, None);
        assert_eq!(status.latest.as_deref(), Some("9.9.9"));
        assert_eq!(status.installed.as_deref(), Some("9.9.9"));
        assert_eq!(
            status.installed_path.as_deref(),
            Some(&*jsh.to_string_lossy())
        );
        assert!(!status.update_available);
        assert_eq!(status.shadowed_by, None);
        assert_eq!(prompt_for(&status), None);
    }

    #[test]
    fn an_unsigned_manifest_emits_a_failed_check_without_an_install_prompt() {
        let Some(fixture) = SignedRelease::new() else {
            return;
        };
        std::fs::remove_file(fixture.manifest().with_extension("json.minisig"))
            .expect("remove manifest signature");
        assert_signature_failure(&fixture, "no signature");
    }

    #[test]
    fn a_tampered_manifest_emits_a_failed_check_without_an_install_prompt() {
        let Some(fixture) = SignedRelease::new() else {
            return;
        };
        // Keep a well-formed manifest and its real signature, but change the
        // signed version so only cryptographic verification can reject it.
        let manifest = std::fs::read_to_string(fixture.manifest()).expect("signed manifest");
        std::fs::write(fixture.manifest(), manifest.replace("9.9.9", "9.9.8"))
            .expect("tamper signed manifest");
        assert_signature_failure(&fixture, "signature verification failed");
    }

    fn assert_signature_failure(fixture: &SignedRelease, expected_error: &str) {
        let output = fixture.command().output().expect("run rejected check");
        let status = SignedRelease::parse(&output);
        assert!(!output.status.success());
        assert!(
            status
                .error
                .as_deref()
                .is_some_and(|error| error.contains(expected_error)),
            "unexpected check error: {:?}",
            status.error
        );
        assert_eq!(status.latest, None);
        assert!(!status.update_available);
        assert_eq!(prompt_for(&status), None);
    }
}
