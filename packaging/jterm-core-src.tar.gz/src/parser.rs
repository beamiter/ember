//! OSC/CSI stream parser. Splits a raw PTY byte stream into semantic
//! `ParserEvent`s — passing through display bytes while extracting the OSC 133
//! shell-integration marks, OSC 52 clipboard, alt-screen toggles and APC
//! sequences that drive the block view. OSC 7/title sequences pass through to
//! VTE so its native cwd/title signals stay authoritative.

/// OSC carries titles and clipboard data. One MiB is ample for supported
/// payloads while bounding malformed strings that never send a terminator.
const MAX_OSC_PAYLOAD_BYTES: usize = 1024 * 1024;

/// Per-field cap for app-driven desktop notifications (OSC 9 / OSC 777),
/// matching the frost in-engine limit so the family behaves identically.
pub const MAX_NOTIFICATION_CHARS: usize = 256;
/// Kitty graphics uses APC. Keep a practical encoded-image ceiling while
/// preventing one unterminated sequence from retaining arbitrary PTY output.
const MAX_APC_PAYLOAD_BYTES: usize = 16 * 1024 * 1024;
/// Sixel and terminal-query DCS payloads are passed through only when complete.
/// Oversized unterminated payloads are discarded until their real terminator.
const MAX_DCS_PAYLOAD_BYTES: usize = 1024 * 1024;
const MAX_CLIPBOARD_BASE64_BYTES: usize = 4 * 1024 * 1024;
const MAX_OSC7_URI_BYTES: usize = 16 * 1024;
const MAX_TITLE_BYTES: usize = 4 * 1024;
/// Per-field caps for the OSC 133 metadata jsh attaches to its C/D packets.
/// jsh bounds these on the way out (`MAX_OSC_COMMAND_BYTES` = 16 KiB,
/// `MAX_OSC_CWD_BYTES` = 4 KiB in jsh/src/osc.rs), but any program can write an
/// OSC 133 packet, so the reader bounds them too rather than trusting a
/// cooperative producer.
/// Maximum decoded command bytes accepted from OSC 133 metadata. This matches
/// jsh's emitter; oversized commands use `cmd_truncated=1` instead.
pub const MAX_OSC133_COMMAND_BYTES: usize = 16 * 1024;
/// Maximum decoded cwd bytes accepted from OSC 133 metadata.
pub const MAX_OSC133_CWD_BYTES: usize = 4 * 1024;
/// Maximum decoded execution-id bytes accepted from OSC 133 metadata. Shells
/// other than jsh may use longer opaque correlation ids; journal persistence
/// independently applies jsh's narrower 192-byte grammar.
pub const MAX_OSC133_ID_BYTES: usize = 1024;
/// Maximum decoded persistent-session identity bytes. Unlike display-only
/// metadata, this must match jsh's exact journal correlation grammar.
pub const MAX_OSC133_SESSION_ID_BYTES: usize = 128;

/// Which color slot an OSC 10/11/12/4 query asked about.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ColorKind {
    /// OSC 10 — default foreground.
    Foreground,
    /// OSC 11 — default background.
    Background,
    /// OSC 12 — cursor color.
    Cursor,
    /// OSC 4;N — palette index N.
    Palette(u8),
}

pub use crate::kitty_keyboard::KittyKeyboardOp;

/// Which terminal-capability handshake an app sent.
///
/// The query bytes also pass through to the live VTE, and the live VTE does
/// have a reply path even with no PTY attached: libvte 0.76 emits every reply
/// through its `commit` signal (`send_child` → `emit_commit`), and the hosts
/// forward commits to the child. For the queries libvte implements, DA1, DA2,
/// DA3, XTVERSION, DSR 5 and CPR, that commit is the answer. A host that
/// synthesises one as well makes the child read two different answers, a
/// frame or more apart. crossterm keeps the unsolicited second CPR for its next
/// cursor query, and a synthesised CPR computed from the host's own view of
/// the grid can disagree with the VTE's. (See
/// [`crate::terminal_report`] for telling those reply commits apart from
/// keystrokes.)
///
/// The host must still answer what libvte does not implement:
/// - `CSI ? u`, because VTE knows nothing of the kitty keyboard protocol and
///   the host owns the flag stacks ([`crate::kitty_keyboard`]);
/// - `CSI ? 4 m` (XTQMODKEYS), which VTE 0.76 ignores.
///
/// A surface with no VTE behind it (headless, recording) answers all of them,
/// or neovim, helix and friends block on the missing response.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum KeyboardProtocolQuery {
    /// `CSI ? u` — kitty progressive-enhancement flag query.
    KittyQuery,
    /// `CSI ? 4 m` — XTQMODKEYS modifyOtherKeys query.
    ModifyOtherKeysQuery,
    /// `CSI c` / `CSI 0 c` — primary device attributes (DA1).
    PrimaryDeviceAttributes,
    /// `CSI > c` / `CSI > 0 c` — secondary device attributes (DA2). Different
    /// reply format from DA1 (`CSI > Pp ; Pv ; Pc c` vs `CSI ? ... c`).
    SecondaryDeviceAttributes,
    /// `CSI = c` / `CSI = 0 c` — tertiary device attributes (DA3).
    TertiaryDeviceAttributes,
    /// `CSI > q` — XTVERSION (xterm name/version request).
    XtVersion,
    /// `CSI 5 n` — DSR: report device status (reply `\e[0n` = OK).
    DeviceStatus,
    /// `CSI 6 n` — DSR: report cursor position (reply `\e[<row>;<col>R`).
    CursorPosition,
}

/// Events emitted by the stream parser.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ParserEvent {
    /// Raw bytes that should be displayed verbatim (ANSI codes stripped of OSC 133/7).
    Bytes(Vec<u8>),
    /// OSC 133 ;A — prompt about to render.
    PromptStart,
    /// OSC 133 ;B — prompt finished, waiting for user input.
    PromptEnd,
    /// OSC 133 ;C — user pressed Enter, command is executing. Carries whatever
    /// [`CommandMeta`] the shell attached; every field is absent for a shell
    /// that emits only the bare FinalTerm mark.
    CommandStart(CommandMeta),
    /// OSC 133 ;D — command finished.
    ///
    /// `exit` is `None` when the shell sent no status or an unparseable one.
    /// That case used to collapse to `Some(0)`, i.e. a command of unknown
    /// outcome was reported as having succeeded.
    CommandEnd {
        exit: Option<i32>,
        meta: CommandMeta,
    },
    /// OSC 7770 — jsh-specific: the remote shell announces its session ID at
    /// startup. The UI stores it on the tab's RemoteConn so subsequent
    /// reconnects pass `--session <id>` and jsh restores cwd/env/aliases.
    RemoteSessionId(String),
    /// OSC 7771 — the bundled local shell integration consumed its private
    /// one-shot token fd and is ready to correlate Agent executions.
    AgentIntegrationReady(String),
    /// CSI ? 47/1047/1049 h — alt screen entered (vim, less, etc.).
    /// Carries the exact DEC private mode so VTE receives matching semantics.
    AltScreenEnter(u32),
    /// CSI ? 47/1047/1049 l — alt screen left.
    AltScreenLeave(u32),
    /// OSC 52 — application set clipboard content.
    ClipboardSet(String),
    /// OSC 52 with `?` — app is asking for current clipboard content.
    /// We reply with an empty payload (`\e]52;c;\e\\`) so probers (tmux/vim)
    /// know we accept SET but don't expose clipboard contents to the shell.
    ClipboardQuery,
    /// APC sequence (ESC _) — Kitty graphics protocol or similar. APC never
    /// reaches the live VTE, and libvte has no kitty graphics anyway, so a
    /// graphics query (`ESC _ G a=q … ESC \`) is answered by the caller or
    /// not at all.
    ApcSequence(Vec<u8>),
    /// CSI private-mode set/reset — permitted DEC private mode change. Emitted
    /// alongside pass-through so block_view can track reporting modes. Modes
    /// disabled by ParserConfig produce neither bytes nor activation events.
    DecsetMode { mode: u32, set: bool },
    /// OSC 10/11/12/4 with a `?` — app is asking the terminal what color it uses.
    /// The query is consumed and never reaches the live VTE, so the caller is
    /// its only answer and must write a `\e]<n>;rgb:RRRR/GGGG/BBBB\e\\` reply
    /// to the PTY.
    ColorQuery(ColorKind),
    /// App queried a keyboard/capability protocol. The bytes still pass
    /// through, and the live VTE answers some of these itself; the caller
    /// replies on the PTY only for the ones it does not (see
    /// [`KeyboardProtocolQuery`]), so the app falls back gracefully instead of
    /// hanging on the reply or reading two.
    KeyboardProtocolQuery(KeyboardProtocolQuery),
    /// `OSC 9 ; <body>` (iTerm2/ConEmu) or
    /// `OSC 777 ; notify ; <title> ; <body>`.
    /// (urxvt) — the application requests a desktop notification. Fields are
    /// bounded to [`MAX_NOTIFICATION_CHARS`] with control and visual-formatting
    /// characters replaced; the UI must still rate-limit before showing it.
    Notification { title: Option<String>, body: String },
    /// OSC 10/11/12 with a color value — the app SET a dynamic color (theme
    /// switching tools, vim `background=`). The raw spec is forwarded verbatim
    /// (apps parse `#RRGGBB`, `rgb:RR/GG/BB`, or X11 names with their toolkit)
    /// and the original bytes still pass through to the live view; the caller
    /// tracks the dynamic value so later [`ParserEvent::ColorQuery`] replies
    /// report it instead of the static theme color.
    ColorSet { kind: ColorKind, spec: String },
    /// OSC 110/111/112 — the app reset a dynamic color back to the default.
    /// Bytes also pass through; the caller drops its tracked dynamic value.
    ColorReset(ColorKind),
    /// `CSI 2 J` / `CSI 02 J` — erase the complete display using an ordinary,
    /// all-digit ED parameter. Both `ESC [` and C1 (`9B` or UTF-8 `C2 9B`)
    /// introducers are recognized. Emitted immediately before the complete,
    /// byte-exact sequence is passed through as [`Self::Bytes`], so callers can
    /// invalidate visible row authority using the pre-feed mapping. Private,
    /// compound, colon and intermediate forms are deliberately not promoted.
    EraseDisplay,
    /// `CSI 3 J` / `CSI 03 J` — xterm erase-scrollback. Supports the same
    /// byte-preserving 7-bit and C1 introducers as [`Self::EraseDisplay`] and is
    /// emitted immediately before the complete sequence is passed through.
    EraseScrollback,
    /// RIS (`ESC c`) — hard terminal reset. Like [`Self::EraseScrollback`],
    /// this is a byte-coalescing barrier emitted before the raw sequence.
    HardReset,
    /// Kitty keyboard protocol flag-stack operation — `CSI > flags u` (push),
    /// `CSI < n u` (pop), `CSI = flags ; mode u` (set). The bytes still pass
    /// through; the caller owns the stacks (see [`crate::kitty_keyboard`])
    /// and must answer the matching `CSI ? u` query from them.
    KittyKeyboard(KittyKeyboardOp),
}

/// Longest accepted OSC 10/11/12 color spec. X11 names and rgb: forms are
/// short; anything longer is malformed and only passes through.
pub const MAX_COLOR_SPEC_CHARS: usize = 128;

#[derive(Clone, Copy)]
enum CsiIntroducer {
    /// The 7-bit representation, `ESC [`.
    EscBracket,
    /// The legacy single-byte C1 representation, `0x9b`.
    C1,
    /// UTF-8 encoded U+009B, `0xc2 0x9b`.
    Utf8C1,
}

impl CsiIntroducer {
    fn len(self) -> usize {
        match self {
            Self::EscBracket | Self::Utf8C1 => 2,
            Self::C1 => 1,
        }
    }

    fn append_to(self, bytes: &mut Vec<u8>) {
        match self {
            Self::EscBracket => bytes.extend_from_slice(b"\x1b["),
            Self::C1 => bytes.push(0x9b),
            Self::Utf8C1 => bytes.extend_from_slice(b"\xc2\x9b"),
        }
    }
}

/// The last few display bytes seen in Ground. Keeping only a suffix is enough
/// to decide whether a following `0x9b` is a UTF-8 continuation, without
/// turning the Ground bulk-copy path back into a per-byte decoder.
#[derive(Default)]
struct GroundUtf8Tail {
    bytes: [u8; 3],
    len: usize,
}

impl GroundUtf8Tail {
    fn clear(&mut self) {
        self.len = 0;
    }

    fn extend(&mut self, bytes: &[u8]) {
        let capacity = self.bytes.len();
        if bytes.len() >= capacity {
            self.bytes.copy_from_slice(&bytes[bytes.len() - capacity..]);
            self.len = capacity;
            return;
        }

        for &byte in bytes {
            if self.len < self.bytes.len() {
                self.bytes[self.len] = byte;
                self.len += 1;
            } else {
                self.bytes.copy_within(1.., 0);
                self.bytes[self.bytes.len() - 1] = byte;
            }
        }
    }

    fn previous(&self, distance: usize) -> Option<u8> {
        (distance != 0 && distance <= self.len).then(|| self.bytes[self.len - distance])
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum C1GroundRole {
    /// UTF-8 U+009B is itself the CSI control.
    Utf8Csi,
    /// `0x9b` belongs to some other valid UTF-8 scalar.
    Utf8Continuation,
    /// A standalone 8-bit CSI introducer.
    Csi,
}

fn valid_first_continuation(lead: u8, continuation: u8) -> bool {
    match lead {
        0xe0 => (0xa0..=0xbf).contains(&continuation),
        0xed => (0x80..=0x9f).contains(&continuation),
        0xf0 => (0x90..=0xbf).contains(&continuation),
        0xf4 => (0x80..=0x8f).contains(&continuation),
        0xe1..=0xec | 0xee..=0xef | 0xf1..=0xf3 => (0x80..=0xbf).contains(&continuation),
        _ => false,
    }
}

fn classify_ground_c1(tail: &GroundUtf8Tail) -> C1GroundRole {
    let Some(previous) = tail.previous(1) else {
        return C1GroundRole::Csi;
    };

    if previous == 0xc2 {
        return C1GroundRole::Utf8Csi;
    }
    if (0xc3..=0xdf).contains(&previous) || valid_first_continuation(previous, 0x9b) {
        return C1GroundRole::Utf8Continuation;
    }

    if (0x80..=0xbf).contains(&previous) {
        if let Some(lead) = tail.previous(2) {
            if (0xe0..=0xef).contains(&lead) && valid_first_continuation(lead, previous) {
                return C1GroundRole::Utf8Continuation;
            }
            if (0xf0..=0xf4).contains(&lead) && valid_first_continuation(lead, previous) {
                return C1GroundRole::Utf8Continuation;
            }
        }

        if let (Some(first_continuation), Some(lead)) = (tail.previous(2), tail.previous(3)) {
            if (0x80..=0xbf).contains(&first_continuation)
                && (0xf0..=0xf4).contains(&lead)
                && valid_first_continuation(lead, first_continuation)
            {
                return C1GroundRole::Utf8Continuation;
            }
        }
    }

    C1GroundRole::Csi
}

#[derive(Default)]
enum State {
    #[default]
    Ground,
    /// Saw ESC, waiting for next byte
    Esc,
    /// Inside CSI: collecting parameter/intermediary bytes while retaining its
    /// exact 7-bit, 8-bit, or UTF-8 C1 introducer for pass-through.
    Csi {
        introducer: CsiIntroducer,
        buf: Vec<u8>,
    },
    /// An overlong CSI is opaque until its final byte or a fresh escape.
    /// Passing the prefix to VTE would bypass our private-mode filtering.
    CsiDiscard,
    /// Inside OSC (ESC ]): collecting bytes until ST (BEL or ESC \)
    Osc { buf: Vec<u8> },
    /// Just saw ESC while in OSC — next byte should be '\' for ST
    OscEsc { payload: Vec<u8> },
    /// OSC exceeded its hard payload limit. Ignore bytes until BEL or ST.
    OscDiscard,
    /// Saw ESC while discarding an oversized OSC; '\' completes ST.
    OscDiscardEsc,
    /// Inside APC (ESC _): collecting bytes for Kitty graphics etc. APC is a
    /// control string and is terminated only by ST, never by BEL.
    Apc { buf: Vec<u8> },
    /// Saw ESC while in APC — next byte should be '\' for ST
    ApcEsc { payload: Vec<u8> },
    /// APC exceeded its hard payload limit. Ignore bytes until ST.
    ApcDiscard,
    /// Saw ESC while discarding an oversized APC; '\' completes ST.
    ApcDiscardEsc,
    /// Inside DCS (ESC P): collect until ST. Unlike `Ignore`, the bytes are
    /// rewrapped as `ESC P ... ESC \` and passed through to the active VTE so
    /// sixel graphics, DECRQSS replies, and tmux passthrough survive block mode.
    Dcs { buf: Vec<u8> },
    /// Saw ESC while in DCS — next byte should be '\' for ST.
    DcsEsc { payload: Vec<u8> },
    /// DCS exceeded its hard payload limit. Ignore bytes until ST.
    DcsDiscard,
    /// Saw ESC while discarding an oversized DCS; '\' completes ST.
    DcsDiscardEsc,
    /// Inside PM (ESC ^) or SOS (ESC X) — consume until ST and discard.
    Ignore,
    /// Saw ESC while in PM/SOS — consume the ST final byte too.
    IgnoreEsc,
}

/// Which mouse-tracking mode the shell asked for. The mode bytes also reach the
/// live VTE, and libvte 0.76 generates SGR (`?1006`) click, drag and motion
/// reports itself, emitted through its `commit` signal even with no PTY. It
/// cannot send the legacy X10 or UTF-8 encodings without one (its
/// `feed_child_binary` returns early), and the hosts synthesise their own
/// wheel reports, so callers read this state for the reports they generate.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum MouseMode {
    #[default]
    None,
    /// `?9` — only button presses (no release).
    X10,
    /// `?1000` — button press + release.
    Normal,
    /// `?1002` — press/release + motion while a button is held.
    ButtonEvent,
    /// `?1003` — press/release + all motion.
    AnyEvent,
}

/// Wire format for mouse reports. Set by `?1006`, `?1015`, `?1005` (or default
/// xterm encoding if none enabled).
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum MouseEncoding {
    /// Legacy `\e[M` + 3 bytes (button + 32, col + 32, row + 32).
    #[default]
    Default,
    /// `?1006` — SGR: `\e[<b;col;row;{M|m}`.
    Sgr,
    /// `?1015` — urxvt: `\e[b;col;row;M`.
    Urxvt,
    /// `?1005` — UTF-8 encoded coordinates.
    Utf8,
}

pub struct Parser {
    state: State,
    passthrough: Vec<u8>,
    ground_utf8_tail: GroundUtf8Tail,
    config: ParserConfig,
    /// `?2004` — shell asked for paste content to be bracketed with `\e[200~`
    /// / `\e[201~`. The caller wraps its own `Paste` write when this is on.
    bracketed_paste: bool,
    /// Independent tracking flags; effective priority matches the live VTE.
    mouse_tracking: u8,
    /// Independent encoding flags; SGR outranks urxvt, then UTF-8.
    mouse_encoding: u8,
    /// `?1004` — shell asked for `\e[I` / `\e[O` on focus enter/leave.
    focus_events: bool,
}

#[derive(Clone, Copy)]
pub struct ParserConfig {
    pub mouse_reporting: bool,
    pub focus_reporting: bool,
}

impl Default for ParserConfig {
    fn default() -> Self {
        Self {
            mouse_reporting: true,
            focus_reporting: true,
        }
    }
}

/// A complete ordinary DEC private-mode list. Only normalize syntax VTE also
/// treats as numeric parameters; intermediates and malformed lists retain
/// their original pass-through behavior.
fn private_modes(params: &[u8]) -> Option<Vec<u32>> {
    // VTE executes C0 controls inside CSI and ignores DEL without changing
    // numeric parameters. They cannot hide a filtered mode from this parser.
    let filtered;
    let params = if params.iter().any(|byte| *byte < 0x20 || *byte == 0x7f) {
        filtered = params
            .iter()
            .copied()
            .filter(|byte| *byte >= 0x20 && *byte != 0x7f)
            .collect::<Vec<_>>();
        filtered.as_slice()
    } else {
        params
    };
    params
        .strip_prefix(b"?")?
        .split(|byte| *byte == b';')
        .map(|token| {
            if !token.iter().all(u8::is_ascii_digit) {
                return None;
            }
            // Omitted values default to zero; an overlarge unknown mode
            // must not hide a later reporting/alt-screen token from filtering.
            Some(token.iter().fold(0_u32, |value, digit| {
                value
                    .saturating_mul(10)
                    .saturating_add(u32::from(*digit - b'0'))
            }))
        })
        .collect()
}

fn is_alt_screen_mode(mode: u32) -> bool {
    matches!(mode, 47 | 1047 | 1049)
}

fn is_mouse_mode(mode: u32) -> bool {
    matches!(
        mode,
        9 | 1000 | 1001 | 1002 | 1003 | 1005 | 1006 | 1015 | 1016
    )
}

fn alt_screen_mode(params: &[u8]) -> Option<u32> {
    match params {
        b"?47" => Some(47),
        b"?1047" => Some(1047),
        b"?1049" => Some(1049),
        _ => None,
    }
}

/// True only for an ordinary (non-private, no-intermediate) CSI parameter with
/// exactly the requested numeric value. Extra parameter fields are deliberately
/// rejected: a semantic side effect must not fire for a malformed/lookalike CSI
/// that VTE may interpret differently. Saturation prevents a hostile oversized
/// parameter from wrapping back onto a recognized value.
fn is_ordinary_numeric_param(params: &[u8], expected: u32) -> bool {
    !params.is_empty()
        && params.iter().all(u8::is_ascii_digit)
        && params.iter().fold(0_u32, |value, digit| {
            value
                .saturating_mul(10)
                .saturating_add(u32::from(*digit - b'0'))
        }) == expected
}

fn is_erase_display(params: &[u8]) -> bool {
    is_ordinary_numeric_param(params, 2)
}

fn is_erase_scrollback(params: &[u8]) -> bool {
    is_ordinary_numeric_param(params, 3)
}

fn is_mouse_reporting_mode(params: &[u8]) -> bool {
    matches!(
        params,
        b"?9"
            | b"?1000"
            | b"?1001"
            | b"?1002"
            | b"?1003"
            | b"?1005"
            | b"?1006"
            | b"?1015"
            | b"?1016"
    )
}

fn is_focus_reporting_mode(params: &[u8]) -> bool {
    matches!(params, b"?1004")
}

/// A small decimal CSI parameter. Non-digits end the number; an absent one is
/// zero, and the value saturates so a hostile width cannot wrap.
fn csi_u8_param(digits: &[u8]) -> u8 {
    digits
        .iter()
        .take_while(|c| c.is_ascii_digit())
        .fold(0_u8, |value, digit| {
            value.saturating_mul(10).saturating_add(digit - b'0')
        })
}

impl Default for Parser {
    fn default() -> Self {
        Self::new()
    }
}

impl Parser {
    pub fn new() -> Self {
        Self::with_config(ParserConfig::default())
    }

    pub fn with_config(config: ParserConfig) -> Self {
        Parser {
            state: State::default(),
            passthrough: Vec::with_capacity(4096),
            ground_utf8_tail: GroundUtf8Tail::default(),
            config,
            bracketed_paste: false,
            mouse_tracking: 0,
            mouse_encoding: 0,
            focus_events: false,
        }
    }

    /// True while the shell has `?2004` enabled — callers should wrap pasted
    /// content with `\e[200~` / `\e[201~` before writing to the PTY.
    #[allow(dead_code)]
    pub fn bracketed_paste(&self) -> bool {
        self.bracketed_paste
    }

    /// Currently active mouse-tracking mode, or `None` when reporting is off.
    #[allow(dead_code)]
    pub fn mouse_mode(&self) -> MouseMode {
        if self.mouse_tracking & 8 != 0 {
            MouseMode::AnyEvent
        } else if self.mouse_tracking & 4 != 0 {
            MouseMode::ButtonEvent
        } else if self.mouse_tracking & 2 != 0 {
            MouseMode::Normal
        } else if self.mouse_tracking & 1 != 0 {
            MouseMode::X10
        } else {
            MouseMode::None
        }
    }

    /// Wire encoding the next mouse report should use.
    #[allow(dead_code)]
    pub fn mouse_encoding(&self) -> MouseEncoding {
        if self.mouse_encoding & 4 != 0 {
            MouseEncoding::Sgr
        } else if self.mouse_encoding & 2 != 0 {
            MouseEncoding::Urxvt
        } else if self.mouse_encoding & 1 != 0 {
            MouseEncoding::Utf8
        } else {
            MouseEncoding::Default
        }
    }

    /// True while `?1004` is enabled — callers should emit `\e[I` on focus-in,
    /// `\e[O` on focus-out.
    #[allow(dead_code)]
    pub fn focus_events(&self) -> bool {
        self.focus_events
    }

    /// Apply each `?N` token from a `CSI ? Pm h/l` to the snooped state.
    /// `enable` = true for `h`, false for `l`. Unknown modes are ignored —
    /// they still pass through to the VTE.
    fn update_dec_private_modes(&mut self, params: &[u8], enable: bool) -> Vec<u32> {
        let mut modes = Vec::new();
        for token in params.split(|&c| c == b';') {
            // Each token may itself start with `?` if the shell sent
            // `CSI ?1;?2 h`; tolerate that.
            let token = token.strip_prefix(b"?").unwrap_or(token);
            let n: u32 = match std::str::from_utf8(token).ok().and_then(|s| s.parse().ok()) {
                Some(n) => n,
                None => continue,
            };
            modes.push(n);
            let (flags, bit) = match n {
                2004 => {
                    self.bracketed_paste = enable;
                    continue;
                }
                1004 => {
                    self.focus_events = enable;
                    continue;
                }
                9 => (&mut self.mouse_tracking, 1),
                1000 => (&mut self.mouse_tracking, 2),
                1002 => (&mut self.mouse_tracking, 4),
                1003 => (&mut self.mouse_tracking, 8),
                1005 => (&mut self.mouse_encoding, 1),
                1015 => (&mut self.mouse_encoding, 2),
                1006 => (&mut self.mouse_encoding, 4),
                _ => continue,
            };
            if enable {
                *flags |= bit;
            } else {
                *flags &= !bit;
            }
        }
        modes
    }

    pub fn feed(&mut self, data: &[u8], events: &mut Vec<ParserEvent>) {
        self.passthrough.clear();

        macro_rules! flush {
            () => {
                if !self.passthrough.is_empty() {
                    events.push(ParserEvent::Bytes(std::mem::take(&mut self.passthrough)));
                }
            };
        }

        macro_rules! hard_reset {
            () => {{
                flush!();
                self.ground_utf8_tail.clear();
                self.bracketed_paste = false;
                self.mouse_tracking = 0;
                self.mouse_encoding = 0;
                self.focus_events = false;
                events.push(ParserEvent::HardReset);
                // RIS itself is an immediate feed boundary. Keeping it in a
                // dedicated Bytes event prevents a later query/DECSET in the
                // same PTY read from being coalesced across the reset hook.
                events.push(ParserEvent::Bytes(b"\x1bc".to_vec()));
                self.state = State::Ground;
            }};
        }

        /// Abort an incomplete control string at its non-ST ESC sequence and
        /// reinterpret the escape introducer plus final byte from scratch.
        /// Keeping this in one local helper avoids subtly different recovery
        /// rules between OSC, APC, DCS, and their oversized discard states.
        macro_rules! reprocess_escape_final {
            ($byte:expr) => {{
                match $byte {
                    0x1b => self.state = State::Esc,
                    b'[' => {
                        self.state = State::Csi {
                            introducer: CsiIntroducer::EscBracket,
                            buf: Vec::new(),
                        }
                    }
                    b']' => self.state = State::Osc { buf: Vec::new() },
                    b'_' => self.state = State::Apc { buf: Vec::new() },
                    b'P' => self.state = State::Dcs { buf: Vec::new() },
                    b'^' | b'X' => self.state = State::Ignore,
                    b'c' => hard_reset!(),
                    byte => {
                        self.passthrough.push(0x1b);
                        self.passthrough.push(byte);
                        self.state = State::Ground;
                    }
                }
            }};
        }

        // Ground-state fast-path: bulk-copy runs until ESC or an 8-bit CSI
        // candidate. The short suffix window crosses feed boundaries, but no
        // byte is withheld: Parser has no EOF signal, so even a trailing UTF-8
        // lead must remain immediate pass-through.
        let mut i = 0usize;
        let len = data.len();
        while i < len {
            if matches!(self.state, State::Ground) {
                match memchr::memchr2(0x1b, 0x9b, &data[i..]) {
                    Some(off) => {
                        if off > 0 {
                            let plain = &data[i..i + off];
                            self.passthrough.extend_from_slice(plain);
                            self.ground_utf8_tail.extend(plain);
                        }
                        i += off;
                        if data[i] == 0x1b {
                            i += 1;
                            self.ground_utf8_tail.clear();
                            self.state = State::Esc;
                        } else {
                            i += 1;
                            match classify_ground_c1(&self.ground_utf8_tail) {
                                C1GroundRole::Utf8Csi => {
                                    // When C2 is in this feed, retain both bytes
                                    // in Csi so the sequence passes through as
                                    // one run. Across a feed boundary C2 has
                                    // already passed through (and cannot affect
                                    // VTE until 9B arrives), so retain only 9B.
                                    let introducer = if self.passthrough.last() == Some(&0xc2) {
                                        self.passthrough.pop();
                                        CsiIntroducer::Utf8C1
                                    } else {
                                        CsiIntroducer::C1
                                    };
                                    self.ground_utf8_tail.clear();
                                    self.state = State::Csi {
                                        introducer,
                                        buf: Vec::new(),
                                    };
                                }
                                C1GroundRole::Utf8Continuation => {
                                    self.passthrough.push(0x9b);
                                    self.ground_utf8_tail.extend(&[0x9b]);
                                }
                                C1GroundRole::Csi => {
                                    self.ground_utf8_tail.clear();
                                    self.state = State::Csi {
                                        introducer: CsiIntroducer::C1,
                                        buf: Vec::new(),
                                    };
                                }
                            }
                        }
                        continue;
                    }
                    None => {
                        let plain = &data[i..];
                        self.passthrough.extend_from_slice(plain);
                        self.ground_utf8_tail.extend(plain);
                        break;
                    }
                }
            }

            let b = data[i];
            i += 1;
            // CAN and SUB abort every pending escape/control string. They
            // must never become part of an OSC lifecycle mark or consume the
            // display text after the cancelled sequence. CSI prefixes already
            // destined for VTE are preserved together with the cancellation.
            if matches!(b, 0x18 | 0x1a) {
                match std::mem::take(&mut self.state) {
                    State::Csi { introducer, buf } => {
                        introducer.append_to(&mut self.passthrough);
                        self.passthrough.extend_from_slice(&buf);
                        self.passthrough.push(b);
                    }
                    State::Esc => self.passthrough.extend_from_slice(&[0x1b, b]),
                    _ => {}
                }
                continue;
            }
            match &mut self.state {
                State::Ground => unreachable!("handled by fast-path above"),

                State::Esc => match b {
                    // A second ESC abandons the first incomplete escape.
                    0x1b => {}
                    b'[' => {
                        // Do NOT emit "ESC[" yet. Buffer the whole CSI in state so a
                        // read boundary falling mid-sequence cannot split it across
                        // two Bytes events — downstream scanners (interactive-mode
                        // detection) rely on seeing each CSI whole.
                        self.state = State::Csi {
                            introducer: CsiIntroducer::EscBracket,
                            buf: Vec::new(),
                        };
                    }
                    b']' => {
                        self.state = State::Osc { buf: Vec::new() };
                    }
                    b'_' => {
                        self.state = State::Apc { buf: Vec::new() };
                    }
                    b'P' => {
                        self.state = State::Dcs { buf: Vec::new() };
                    }
                    // PM (`ESC ^`) and SOS (`ESC X`) are control strings whose
                    // payload is ignored through ST. Treat both alike here;
                    // their ESC + non-ST recovery is handled below.
                    b'^' | b'X' => {
                        self.state = State::Ignore;
                    }
                    b'c' => {
                        hard_reset!();
                    }
                    _ => {
                        self.passthrough.push(0x1b);
                        self.passthrough.push(b);
                        self.state = State::Ground;
                    }
                },

                State::Csi { introducer, buf } => {
                    if b == 0x1b {
                        introducer.append_to(&mut self.passthrough);
                        self.passthrough.extend_from_slice(buf);
                        self.state = State::Esc;
                    } else if (0x40..=0x7e).contains(&b) {
                        // Final byte of CSI sequence
                        let introducer = *introducer;
                        let params = std::mem::take(buf);
                        self.state = State::Ground;
                        // A compound DECSET can contain an alt-screen switch
                        // or a disabled reporting mode beside ordinary modes.
                        // Split only these intercepted lists, in wire order:
                        // host-owned alt transitions consume their token while
                        // VTE still receives every permitted companion token.
                        if matches!(b, b'h' | b'l') {
                            if let Some(modes) = private_modes(&params) {
                                if modes.iter().any(|mode| {
                                    is_alt_screen_mode(*mode)
                                        || (!self.config.mouse_reporting && is_mouse_mode(*mode))
                                        || (!self.config.focus_reporting && *mode == 1004)
                                }) {
                                    // Embedded C0 controls execute before the
                                    // final byte applies modes, even when the
                                    // surrounding mode sequence is intercepted.
                                    self.passthrough
                                        .extend(params.iter().copied().filter(|byte| *byte < 0x20));
                                    flush!();
                                    for mode in modes {
                                        if is_alt_screen_mode(mode) {
                                            flush!();
                                            events.push(if b == b'h' {
                                                ParserEvent::AltScreenEnter(mode)
                                            } else {
                                                ParserEvent::AltScreenLeave(mode)
                                            });
                                        } else {
                                            flush!();
                                            if (!self.config.mouse_reporting && is_mouse_mode(mode))
                                                || (!self.config.focus_reporting && mode == 1004)
                                            {
                                                // Hosts synthesize wheel/focus reports
                                                // from these events. Suppress both the
                                                // wire bytes and semantic activation.
                                                continue;
                                            }
                                            let token = mode.to_string();
                                            self.update_dec_private_modes(
                                                token.as_bytes(),
                                                b == b'h',
                                            );
                                            events.push(ParserEvent::DecsetMode {
                                                mode,
                                                set: b == b'h',
                                            });
                                            // Normalize C1 to ESC[ here too. A UTF-8
                                            // C2 introducer may have passed through
                                            // in the preceding feed; ESC safely
                                            // starts a fresh control sequence.
                                            self.passthrough.extend_from_slice(b"\x1b[?");
                                            self.passthrough.extend_from_slice(token.as_bytes());
                                            self.passthrough.push(b);
                                        }
                                    }
                                    continue;
                                }
                            }
                        }
                        let alt_mode = alt_screen_mode(&params);
                        if (b == b'h' || b == b'l') && alt_mode.is_none() {
                            if let Some(modes) = private_modes(&params) {
                                for mode in modes {
                                    self.update_dec_private_modes(
                                        mode.to_string().as_bytes(),
                                        b == b'h',
                                    );
                                    events.push(ParserEvent::DecsetMode {
                                        mode,
                                        set: b == b'h',
                                    });
                                }
                            }
                        }
                        let erase_display = b == b'J' && is_erase_display(&params);
                        let erase_scrollback = b == b'J' && is_erase_scrollback(&params);
                        let erase_barrier = erase_display || erase_scrollback;
                        if erase_barrier {
                            flush!();
                            events.push(if erase_display {
                                ParserEvent::EraseDisplay
                            } else {
                                ParserEvent::EraseScrollback
                            });
                            // Like RIS, ED2/ED3 must reach VTE before any suffix
                            // event from this same feed is dispatched.
                            let mut sequence =
                                Vec::with_capacity(params.len() + introducer.len() + 1);
                            introducer.append_to(&mut sequence);
                            sequence.extend_from_slice(&params);
                            sequence.push(b);
                            events.push(ParserEvent::Bytes(sequence));
                        }
                        if let (b'h', Some(mode)) = (b, alt_mode) {
                            // Recognized alt-screen enter: drop the sequence bytes
                            // (never passed through) and emit the exact DEC mode.
                            flush!();
                            events.push(ParserEvent::AltScreenEnter(mode));
                        } else if let (b'l', Some(mode)) = (b, alt_mode) {
                            flush!();
                            events.push(ParserEvent::AltScreenLeave(mode));
                        } else if !self.config.mouse_reporting
                            && (b == b'h' || b == b'l')
                            && is_mouse_reporting_mode(&params)
                        {
                            // Drop: keep VTE out of mouse reporting mode.
                        } else if !self.config.focus_reporting
                            && (b == b'h' || b == b'l')
                            && is_focus_reporting_mode(&params)
                        {
                            // Drop: keep VTE out of focus reporting mode.
                        } else if !erase_barrier {
                            // Detect terminal-capability handshakes. The byte
                            // stream itself is still passed through, and the live
                            // VTE answers the ones libvte implements (DA1/2/3,
                            // XTVERSION, DSR 5/6) through its `commit` signal, which
                            // the host forwards to the PTY; the host must not answer
                            // those twice. It synthesizes the rest (kitty `?u`,
                            // `?4m`), and a surface with no VTE answers them all —
                            // see `KeyboardProtocolQuery`.
                            //
                            // `CSI ? u`                       — kitty keyboard query
                            // `CSI ? 4 m`                     — XTQMODKEYS query
                            // `CSI c`, `CSI 0 c`              — primary DA (DA1)
                            // `CSI > c`, `CSI > 0 c`          — secondary DA (DA2)
                            // `CSI = c`, `CSI = 0 c`          — tertiary DA (DA3)
                            // `CSI > q`                       — XTVERSION
                            // `CSI 5 n` / `CSI 6 n`           — DSR status / cursor pos
                            match (b, params.as_slice()) {
                                (b'u', b"?") => {
                                    events.push(ParserEvent::KeyboardProtocolQuery(
                                        KeyboardProtocolQuery::KittyQuery,
                                    ));
                                }
                                (b'u', p) if p.first() == Some(&b'>') => {
                                    events.push(ParserEvent::KittyKeyboard(KittyKeyboardOp::Push(
                                        csi_u8_param(&p[1..]),
                                    )));
                                }
                                (b'u', p) if p.first() == Some(&b'<') => {
                                    events.push(ParserEvent::KittyKeyboard(KittyKeyboardOp::Pop(
                                        csi_u8_param(&p[1..]),
                                    )));
                                }
                                (b'u', p) if p.first() == Some(&b'=') => {
                                    let mut fields = p[1..].split(|&c| c == b';');
                                    let flags = csi_u8_param(fields.next().unwrap_or(b""));
                                    let mode = fields
                                        .next()
                                        .map(csi_u8_param)
                                        .filter(|mode| *mode != 0)
                                        .unwrap_or(1);
                                    events.push(ParserEvent::KittyKeyboard(KittyKeyboardOp::Set {
                                        flags,
                                        mode,
                                    }));
                                }
                                (b'm', b"?4") => {
                                    events.push(ParserEvent::KeyboardProtocolQuery(
                                        KeyboardProtocolQuery::ModifyOtherKeysQuery,
                                    ));
                                }
                                (b'c', b"") | (b'c', b"0") => {
                                    events.push(ParserEvent::KeyboardProtocolQuery(
                                        KeyboardProtocolQuery::PrimaryDeviceAttributes,
                                    ));
                                }
                                (b'c', b">") | (b'c', b">0") => {
                                    events.push(ParserEvent::KeyboardProtocolQuery(
                                        KeyboardProtocolQuery::SecondaryDeviceAttributes,
                                    ));
                                }
                                (b'c', b"=") | (b'c', b"=0") => {
                                    events.push(ParserEvent::KeyboardProtocolQuery(
                                        KeyboardProtocolQuery::TertiaryDeviceAttributes,
                                    ));
                                }
                                (b'q', b">") | (b'q', b">0") => {
                                    events.push(ParserEvent::KeyboardProtocolQuery(
                                        KeyboardProtocolQuery::XtVersion,
                                    ));
                                }
                                (b'n', b"5") => {
                                    events.push(ParserEvent::KeyboardProtocolQuery(
                                        KeyboardProtocolQuery::DeviceStatus,
                                    ));
                                }
                                (b'n', b"6") => {
                                    events.push(ParserEvent::KeyboardProtocolQuery(
                                        KeyboardProtocolQuery::CursorPosition,
                                    ));
                                }
                                _ => {}
                            }
                            // Pass the complete sequence through as one contiguous run.
                            introducer.append_to(&mut self.passthrough);
                            self.passthrough.extend_from_slice(&params);
                            self.passthrough.push(b);
                        }
                    } else {
                        buf.push(b);
                        // Bound malformed CSI without feeding an unfiltered
                        // prefix into VTE or exposing its suffix as display text.
                        if buf.len() > 4096 {
                            self.state = State::CsiDiscard;
                        }
                    }
                }

                State::CsiDiscard => match b {
                    0x1b => self.state = State::Esc,
                    0x40..=0x7e => self.state = State::Ground,
                    _ => {}
                },

                State::Osc { buf } => match b {
                    0x07 => {
                        let payload = std::mem::take(buf);
                        self.state = State::Ground;
                        flush!();
                        handle_osc(&payload, events);
                    }
                    0x1b => {
                        let payload = std::mem::take(buf);
                        self.state = State::OscEsc { payload };
                    }
                    _ => {
                        if buf.len() >= MAX_OSC_PAYLOAD_BYTES {
                            log::warn!("Dropping OSC larger than {MAX_OSC_PAYLOAD_BYTES} bytes");
                            // Release the accumulated payload immediately, then
                            // resynchronise only at this string's terminator.
                            self.state = State::OscDiscard;
                        } else {
                            buf.push(b);
                        }
                    }
                },

                State::OscEsc { payload } => {
                    if b == b'\\' {
                        let payload = std::mem::take(payload);
                        self.state = State::Ground;
                        flush!();
                        handle_osc(&payload, events);
                    } else {
                        // ESC followed by a non-ST byte aborts the incomplete
                        // OSC. Do not accept its payload (especially OSC 133),
                        // and reinterpret this ESC + byte as a fresh escape
                        // sequence. The byte is processed inline so RIS and
                        // suffix semantic events keep exact stream order.
                        reprocess_escape_final!(b);
                    }
                }

                State::OscDiscard => match b {
                    0x07 => self.state = State::Ground,
                    0x1b => self.state = State::OscDiscardEsc,
                    _ => {}
                },

                State::OscDiscardEsc => {
                    if b == b'\\' {
                        self.state = State::Ground;
                    } else {
                        reprocess_escape_final!(b);
                    }
                }

                State::Apc { buf } => match b {
                    0x1b => {
                        let payload = std::mem::take(buf);
                        self.state = State::ApcEsc { payload };
                    }
                    _ => {
                        if buf.len() >= MAX_APC_PAYLOAD_BYTES {
                            log::warn!("Dropping APC larger than {MAX_APC_PAYLOAD_BYTES} bytes");
                            self.state = State::ApcDiscard;
                        } else {
                            buf.push(b);
                        }
                    }
                },

                State::ApcEsc { payload } => {
                    if b == b'\\' {
                        let payload = std::mem::take(payload);
                        self.state = State::Ground;
                        flush!();
                        events.push(ParserEvent::ApcSequence(payload));
                    } else {
                        reprocess_escape_final!(b);
                    }
                }

                State::ApcDiscard => {
                    if b == 0x1b {
                        self.state = State::ApcDiscardEsc;
                    }
                }

                State::ApcDiscardEsc => {
                    if b == b'\\' {
                        self.state = State::Ground;
                    } else {
                        reprocess_escape_final!(b);
                    }
                }

                State::Dcs { buf } => match b {
                    0x1b => {
                        let payload = std::mem::take(buf);
                        self.state = State::DcsEsc { payload };
                    }
                    _ => {
                        if buf.len() >= MAX_DCS_PAYLOAD_BYTES {
                            log::warn!("Dropping DCS larger than {MAX_DCS_PAYLOAD_BYTES} bytes");
                            self.state = State::DcsDiscard;
                        } else {
                            buf.push(b);
                        }
                    }
                },

                State::DcsEsc { payload } => {
                    if b == b'\\' {
                        let payload = std::mem::take(payload);
                        self.state = State::Ground;
                        emit_dcs_passthrough(&payload, &mut self.passthrough);
                    } else {
                        reprocess_escape_final!(b);
                    }
                }

                State::DcsDiscard => {
                    if b == 0x1b {
                        self.state = State::DcsDiscardEsc;
                    }
                }

                State::DcsDiscardEsc => {
                    if b == b'\\' {
                        self.state = State::Ground;
                    } else {
                        reprocess_escape_final!(b);
                    }
                }

                State::Ignore => {
                    if b == 0x1b {
                        self.state = State::IgnoreEsc;
                    }
                }

                State::IgnoreEsc => {
                    if b == b'\\' {
                        self.state = State::Ground;
                    } else {
                        reprocess_escape_final!(b);
                    }
                }
            }
        }

        flush!();
    }
}

/// Rewrap a DCS payload as `ESC P ... ESC \` and append to the passthrough buffer
/// so the active VTE — which can interpret sixel, DECRQSS replies, tmux
/// passthrough, etc. — gets the original sequence verbatim.
fn emit_dcs_passthrough(payload: &[u8], passthrough: &mut Vec<u8>) {
    passthrough.reserve(payload.len() + 4);
    passthrough.push(0x1b);
    passthrough.push(b'P');
    passthrough.extend_from_slice(payload);
    passthrough.push(0x1b);
    passthrough.push(b'\\');
}

/// The metadata a shell attaches to its OSC 133 `C` and `D` packets.
///
/// jsh — the family's own shell — carries the command line, the execution id it
/// keys its execution journal on, the cwd and the measured duration, all
/// percent-encoded (see `jsh/src/osc.rs`, whose tests pin the exact bytes).
/// This parser used to split on `;`, read the mark, and throw every parameter
/// away, so the two frontends that share it reconstructed the command by
/// scraping it back off the screen and could never correlate their captured
/// output with a journal record — while [`crate::execution_journal::submit`]
/// existed for exactly that.
///
/// Every field is optional for terminal UI: the same mark is emitted by shells
/// that send no metadata at all, and a field whose encoding is malformed,
/// oversized or not UTF-8 is dropped rather than guessed at. Durable Output is
/// stricter: all four Start identity slots must come from one C packet before
/// [`crate::execution_journal::ExecutionLifecycle`] can be constructed. D
/// packets never populate those Start-only slots.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct CommandMeta {
    /// The shell's own execution id — the correlation key into its journal.
    pub id: Option<String>,
    /// Persistent shell session that owns this execution lifecycle.
    pub session_id: Option<String>,
    /// Shell-local sequence number of this exact Start generation.
    pub seq: Option<u64>,
    /// Wall-clock identity copied from the matching journal Start.
    pub started_at_ms: Option<u64>,
    /// The command line as the shell parsed it, not as the screen rendered it.
    pub command: Option<String>,
    /// Working directory the command ran in.
    pub cwd: Option<String>,
    /// Wall-clock duration the shell measured, which beats a timer started when
    /// the frontend happened to notice the mark.
    pub duration_ms: Option<u64>,
    /// The shell had a command line but it exceeded the packet budget, so
    /// [`CommandMeta::command`] is absent for a reason worth telling apart from
    /// "this shell sends no metadata".
    pub command_truncated: bool,
}

impl CommandMeta {
    /// Parse the `key=value` fields of an OSC 133 packet.
    ///
    /// Key aliases follow ember's decoder, which is the family's most complete
    /// and has been reading jsh's packets in production; accepting its spellings
    /// means the shared parser cannot understand *less* than the frontend that
    /// already had its own.
    fn from_fields<'a>(fields: impl Iterator<Item = &'a str>, accept_start_identity: bool) -> Self {
        let mut meta = Self::default();
        // Aliases name the same semantic slot. Reject a repeated slot instead
        // of applying last-wins semantics to a journal correlation id,
        // command, cwd, or duration supplied by untrusted PTY output.
        let mut seen_id = false;
        let mut seen_session_id = false;
        let mut seen_seq = false;
        let mut seen_started_at_ms = false;
        let mut seen_command = false;
        let mut seen_cwd = false;
        let mut seen_duration = false;
        let mut seen_command_truncated = false;
        for field in fields {
            let Some((key, value)) = field.split_once('=') else {
                continue;
            };
            match key {
                "id" | "jsh_id" | "execution_id" | "command_id" => {
                    if std::mem::replace(&mut seen_id, true) {
                        meta.id = None;
                        continue;
                    }
                    meta.id = decode_osc133(value, MAX_OSC133_ID_BYTES).filter(|id| {
                        !id.is_empty()
                            && !id.chars().any(char::is_control)
                            && !id
                                .chars()
                                .any(crate::review_input::is_terminal_visual_spoofing_character)
                    });
                }
                "session_id" => {
                    if !accept_start_identity {
                        continue;
                    }
                    if std::mem::replace(&mut seen_session_id, true) {
                        meta.session_id = None;
                        continue;
                    }
                    meta.session_id = decode_osc133(value, MAX_OSC133_SESSION_ID_BYTES)
                        .filter(|id| crate::execution_journal::is_valid_jsh_session_id(id));
                }
                "seq" => {
                    if !accept_start_identity {
                        continue;
                    }
                    if std::mem::replace(&mut seen_seq, true) {
                        meta.seq = None;
                        continue;
                    }
                    meta.seq = value.parse().ok();
                }
                "started_at_ms" => {
                    if !accept_start_identity {
                        continue;
                    }
                    if std::mem::replace(&mut seen_started_at_ms, true) {
                        meta.started_at_ms = None;
                        continue;
                    }
                    meta.started_at_ms = value.parse().ok();
                }
                "cmdline_url" | "command_url" | "command" | "cmdline" => {
                    if std::mem::replace(&mut seen_command, true) {
                        meta.command = None;
                        continue;
                    }
                    meta.command = decode_osc133(value, MAX_OSC133_COMMAND_BYTES)
                        .filter(|text| crate::execution_journal::is_valid_jsh_command(text));
                }
                "cwd_url" | "cwd" => {
                    if std::mem::replace(&mut seen_cwd, true) {
                        meta.cwd = None;
                        continue;
                    }
                    meta.cwd = decode_osc133(value, MAX_OSC133_CWD_BYTES)
                        .filter(|text| crate::execution_journal::is_valid_jsh_cwd(text));
                }
                "duration_ms" | "duration" => {
                    if std::mem::replace(&mut seen_duration, true) {
                        meta.duration_ms = None;
                        continue;
                    }
                    meta.duration_ms = value.trim().parse().ok();
                }
                "cmd_truncated" | "command_truncated" => {
                    if std::mem::replace(&mut seen_command_truncated, true) {
                        // Ambiguous disclosure must not turn a known truncated
                        // command back into an apparently complete one.
                        meta.command_truncated = true;
                        continue;
                    }
                    let value = value.trim();
                    meta.command_truncated = match value {
                        "0" => false,
                        "1" => true,
                        value if value.eq_ignore_ascii_case("false") => false,
                        value if value.eq_ignore_ascii_case("true") => true,
                        // A producer chose to send the disclosure but did not
                        // encode its state. Treat that as inexact, not as the
                        // default `false` that claims a command is complete.
                        _ => true,
                    };
                }
                _ => {}
            }
        }
        // jsh emits either an exact command or `cmd_truncated=1`, never both.
        // A contradictory producer must not smuggle a partial prefix into the
        // exact-command path merely by attaching the honest disclosure too.
        if meta.command_truncated {
            meta.command = None;
        }
        meta
    }
}

/// Strict percent-decode of one OSC 133 metadata field.
///
/// Strict on purpose, following ember: a truncated escape, an oversized value
/// or invalid UTF-8 yields `None` rather than a best-effort string, because the
/// decoded value is used as a filesystem path, a journal key, and text put in
/// front of the user. Half-decoded input is worse than none.
fn decode_osc133(value: &str, max_bytes: usize) -> Option<String> {
    let bytes = value.as_bytes();
    let mut decoded: Vec<u8> = Vec::with_capacity(bytes.len().min(max_bytes));
    let mut i = 0;
    while i < bytes.len() {
        let byte = if bytes[i] == b'%' {
            // Needs two more bytes; `i + 2` must be a valid index.
            if i + 2 >= bytes.len() {
                return None;
            }
            let high = (bytes[i + 1] as char).to_digit(16)? as u8;
            let low = (bytes[i + 2] as char).to_digit(16)? as u8;
            i += 3;
            (high << 4) | low
        } else {
            let byte = bytes[i];
            i += 1;
            byte
        };
        if decoded.len() == max_bytes {
            return None;
        }
        decoded.push(byte);
    }
    String::from_utf8(decoded).ok()
}

fn valid_remote_session_id(id: &str) -> bool {
    crate::execution_journal::is_valid_jsh_session_id(id)
}

/// Decode the one outcome slot supported by the family's OSC 133 D packets.
///
/// FinalTerm places it positionally, while existing family integrations also
/// use one of three named spellings. An attempted second slot is ambiguous even
/// if either value is malformed, so it cannot leave an apparently authoritative
/// success or failure behind.
fn parse_osc133_exit_status<'a>(fields: impl Iterator<Item = &'a str>) -> Option<i32> {
    let mut seen = false;
    let mut parsed = None;
    for field in fields {
        let candidate = match field.split_once('=') {
            Some(("exit" | "exit_code" | "exit_status", value)) => {
                Some(value.trim().parse::<i32>().ok())
            }
            Some(_) => None,
            // Unknown bare extension flags are not outcome slots. A numeric
            // bare field is the portable positional status wherever Ember's
            // established decoder already accepts it.
            None => field.trim().parse::<i32>().ok().map(Some),
        };
        let Some(candidate) = candidate else {
            continue;
        };
        if std::mem::replace(&mut seen, true) {
            return None;
        }
        parsed = candidate;
    }
    parsed
}

fn handle_osc(payload: &[u8], events: &mut Vec<ParserEvent>) {
    let s = match std::str::from_utf8(payload) {
        Ok(s) => s,
        Err(_) => return,
    };

    // OSC 133 ; <mark> [; params...] — shell integration (FTCS).
    if let Some(rest) = s.strip_prefix("133;") {
        let mut fields = rest.split(';');
        match fields.next() {
            Some("A") => events.push(ParserEvent::PromptStart),
            Some("B") => events.push(ParserEvent::PromptEnd),
            Some("C") => {
                events.push(ParserEvent::CommandStart(CommandMeta::from_fields(
                    fields, true,
                )));
            }
            Some("D") => {
                let exit = parse_osc133_exit_status(fields.clone());
                events.push(ParserEvent::CommandEnd {
                    exit,
                    meta: CommandMeta::from_fields(fields, false),
                });
            }
            _ => {}
        }
        return;
    }

    // OSC 7770 ; <session-id> — jsh-specific session announce (see jsh osc.rs:107).
    if let Some(rest) = s.strip_prefix("7770;") {
        // Session IDs are protocol identifiers, not display text. Do not trim
        // an invalid payload into a different valid identity: jsh's grammar is
        // already an exact 1-128-byte ASCII token.
        let id = rest;
        if valid_remote_session_id(id) {
            events.push(ParserEvent::RemoteSessionId(id.to_string()));
        }
        return;
    }

    // OSC 7771 ; <32-hex-token> — local Forge shell integration readiness.
    // The token came from a one-shot inherited fd rather than argv/env. Keep
    // this packet out of VTE and let the pane compare it with its private copy.
    if let Some(token) = s.strip_prefix("7771;") {
        if token.len() == 32 && token.bytes().all(|byte| byte.is_ascii_hexdigit()) {
            events.push(ParserEvent::AgentIntegrationReady(token.to_string()));
        }
        return;
    }

    // OSC 7 (cwd), OSC 0 / 1 / 2 (title/icon), and everything else: pass through
    // unchanged. VTE consumes them natively and fires
    // current-directory-uri-notify / window-title-changed signals, which the
    // block_view subscribes to instead of re-parsing here.
    if s.starts_with("7;") {
        if payload.len() > MAX_OSC7_URI_BYTES || !safe_osc7_text(s) {
            return;
        }
        let mut bytes = Vec::with_capacity(payload.len() + 4);
        bytes.push(0x1b);
        bytes.push(b']');
        bytes.extend_from_slice(payload);
        bytes.extend_from_slice(b"\x1b\\");
        events.push(ParserEvent::Bytes(bytes));
        return;
    }

    // iTerm2's legacy CurrentDir field is a raw path with no documented
    // escaping. Let a bounded, unambiguous exact value reach VTE, but do not
    // forward delimiters or invisible formatting into semantic-history state.
    // OSC 7 remains the canonical encoded cwd signal used by jsh.
    if let Some(path) = s.strip_prefix("1337;CurrentDir=") {
        if path.contains(';') || !crate::execution_journal::is_valid_jsh_cwd(path) {
            return;
        }
    }

    // Title/icon strings become trusted-looking window and tab chrome in the
    // frontends. Drop an unsafe update instead of letting terminal output
    // reorder or invisibly alter that UI label.
    if matches!(s.split_once(';'), Some(("0" | "1" | "2", _)))
        && (payload.len() > MAX_TITLE_BYTES
            || s.chars().any(char::is_control)
            || s.chars()
                .any(crate::review_input::is_terminal_visual_spoofing_character))
    {
        return;
    }

    // OSC 9 ; <text> — iTerm2/ConEmu-style desktop notification request.
    if let Some(rest) = s.strip_prefix("9;") {
        let body = bounded_notification_field(rest);
        if !body.is_empty() {
            events.push(ParserEvent::Notification { title: None, body });
        }
        return;
    }

    // OSC 777 ; notify ; <title> ; <body> — urxvt notification extension.
    // Other OSC 777 subcommands fall through to the generic pass-through.
    if let Some(rest) = s.strip_prefix("777;") {
        let mut fields = rest.splitn(3, ';');
        if fields.next() == Some("notify") {
            let title = bounded_notification_field(fields.next().unwrap_or(""));
            let body = bounded_notification_field(fields.next().unwrap_or(""));
            if !(title.is_empty() && body.is_empty()) {
                events.push(ParserEvent::Notification {
                    title: (!title.is_empty()).then_some(title),
                    body,
                });
            }
            return;
        }
    }

    // OSC 10 ; ? / OSC 11 ; ? / OSC 12 ; ?  — color queries (XParseColor reply).
    // The query is consumed here and never reaches the live VTE, so the caller
    // is its only answer (libvte would otherwise reply through `commit` too).
    // The caller owns these colors, the theme plus any tracked OSC 10/11/12
    // override, and it answers at parse time: ahead of a DA1 sentinel that
    // follows, and without waiting for the VTE's next processing tick, which
    // in an unmapped pane is 100 ms away. So: emit a semantic event and let
    // the caller write the one reply on the real PTY. A SET (any non-`?`
    // value) additionally emits ColorSet and falls through to the byte
    // pass-through so the live view recolors natively while the caller
    // tracks the value.
    for (prefix, kind) in [
        ("10;", ColorKind::Foreground),
        ("11;", ColorKind::Background),
        ("12;", ColorKind::Cursor),
    ] {
        if let Some(rest) = s.strip_prefix(prefix) {
            if rest.starts_with('?') {
                events.push(ParserEvent::ColorQuery(kind));
                return;
            }
            let spec = rest.trim();
            if !spec.is_empty() && spec.chars().count() <= MAX_COLOR_SPEC_CHARS {
                events.push(ParserEvent::ColorSet {
                    kind,
                    spec: spec.to_string(),
                });
            }
        }
    }

    // OSC 110/111/112 — reset a dynamic color; bytes also pass through.
    for (code, kind) in [
        ("110", ColorKind::Foreground),
        ("111", ColorKind::Background),
        ("112", ColorKind::Cursor),
    ] {
        if s == code
            || s.strip_prefix(code)
                .is_some_and(|rest| rest.starts_with(';'))
        {
            events.push(ParserEvent::ColorReset(kind));
        }
    }

    // OSC 4 ; <idx> ; ? — palette color query.
    if let Some(rest) = s.strip_prefix("4;") {
        let mut it = rest.splitn(2, ';');
        if let (Some(idx_str), Some(value)) = (it.next(), it.next()) {
            if value.starts_with('?') {
                if let Ok(idx) = idx_str.parse::<u8>() {
                    events.push(ParserEvent::ColorQuery(ColorKind::Palette(idx)));
                    return;
                }
            }
        }
    }

    // OSC 52 ; <selection> ; <base64-data | ?> — clipboard set / query
    if let Some(rest) = s.strip_prefix("52;") {
        if let Some(data_start) = rest.find(';') {
            let b64_data = &rest[data_start + 1..];
            if b64_data == "?" {
                events.push(ParserEvent::ClipboardQuery);
            } else if b64_data.len() <= MAX_CLIPBOARD_BASE64_BYTES {
                if let Ok(decoded) = base64_decode(b64_data.as_bytes()) {
                    if let Ok(text) = String::from_utf8(decoded) {
                        events.push(ParserEvent::ClipboardSet(text));
                    }
                }
            } else {
                log::warn!(
                    "Ignoring OSC 52 payload larger than {MAX_CLIPBOARD_BASE64_BYTES} bytes"
                );
            }
        }
        return;
    }

    // All other OSC sequences: reconstruct and pass through.
    let mut bytes = Vec::with_capacity(payload.len() + 4);
    bytes.push(0x1b);
    bytes.push(b']');
    bytes.extend_from_slice(payload);
    bytes.push(0x07);
    events.push(ParserEvent::Bytes(bytes));
}

/// Validate both the wire spelling and the value a URI consumer sees after
/// percent decoding. Checking only the former lets `%0a` or `%E2%80%AE`
/// reappear as a line break or bidi override in cwd-derived terminal chrome.
fn safe_osc7_text(value: &str) -> bool {
    if value.chars().any(char::is_control)
        || value
            .chars()
            .any(crate::review_input::is_terminal_visual_spoofing_character)
    {
        return false;
    }

    let bytes = value.as_bytes();
    let mut decoded = Vec::with_capacity(bytes.len());
    let mut index = 0usize;
    while index < bytes.len() {
        if bytes[index] == b'%' {
            if index.saturating_add(2) >= bytes.len() {
                return false;
            }
            let Some(high) = (bytes[index + 1] as char).to_digit(16) else {
                return false;
            };
            let Some(low) = (bytes[index + 2] as char).to_digit(16) else {
                return false;
            };
            decoded.push(((high << 4) | low) as u8);
            index += 3;
        } else {
            decoded.push(bytes[index]);
            index += 1;
        }
    }
    String::from_utf8(decoded).is_ok_and(|decoded| {
        !decoded.chars().any(char::is_control)
            && !decoded
                .chars()
                .any(crate::review_input::is_terminal_visual_spoofing_character)
    })
}

/// Bound one OSC 9/777 field: strip control characters (the text reaches
/// notification daemons verbatim), expose visual formatting as replacement
/// glyphs, collapse surrounding whitespace, and cap the length. Applications,
/// not users, author these strings.
fn bounded_notification_field(raw: &str) -> String {
    raw.chars()
        .map(|ch| {
            if ch.is_control() || crate::review_input::is_terminal_visual_spoofing_character(ch) {
                '\u{fffd}'
            } else {
                ch
            }
        })
        .take(MAX_NOTIFICATION_CHARS)
        .collect::<String>()
        .trim()
        .to_string()
}

fn base64_decode(input: &[u8]) -> Result<Vec<u8>, ()> {
    const TABLE: [u8; 256] = {
        let mut t = [0xFFu8; 256];
        let mut i = 0u8;
        loop {
            if i >= 26 {
                break;
            }
            t[(b'A' + i) as usize] = i;
            i += 1;
        }
        i = 0;
        loop {
            if i >= 26 {
                break;
            }
            t[(b'a' + i) as usize] = 26 + i;
            i += 1;
        }
        i = 0;
        loop {
            if i >= 10 {
                break;
            }
            t[(b'0' + i) as usize] = 52 + i;
            i += 1;
        }
        t[b'+' as usize] = 62;
        t[b'/' as usize] = 63;
        t
    };

    let mut out = Vec::with_capacity(input.len() * 3 / 4);
    let mut buf: u32 = 0;
    let mut bits: u32 = 0;

    for &b in input {
        if b == b'=' || b == b'\n' || b == b'\r' {
            continue;
        }
        let val = TABLE[b as usize];
        if val == 0xFF {
            return Err(());
        }
        buf = (buf << 6) | val as u32;
        bits += 6;
        if bits >= 8 {
            bits -= 8;
            out.push((buf >> bits) as u8);
            buf &= (1 << bits) - 1;
        }
    }
    Ok(out)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn collect_bytes(events: &[ParserEvent]) -> Vec<u8> {
        let mut out = Vec::new();
        for e in events {
            if let ParserEvent::Bytes(b) = e {
                out.extend_from_slice(b);
            }
        }
        out
    }

    #[test]
    fn ed2_ed3_and_ris_are_pre_feed_coalescing_barriers() {
        for (sequence, semantic) in [
            (b"\x1b[2J".as_slice(), ParserEvent::EraseDisplay),
            (b"\x1b[02J".as_slice(), ParserEvent::EraseDisplay),
            (b"\x1b[3J".as_slice(), ParserEvent::EraseScrollback),
            (b"\x1b[03J".as_slice(), ParserEvent::EraseScrollback),
            (b"\x1bc".as_slice(), ParserEvent::HardReset),
        ] {
            let mut parser = Parser::new();
            let mut events = Vec::new();
            let mut input = b"before".to_vec();
            input.extend_from_slice(sequence);
            input.extend_from_slice(b"after");
            parser.feed(&input, &mut events);
            assert_eq!(events[0], ParserEvent::Bytes(b"before".to_vec()));
            assert_eq!(events[1], semantic);
            assert_eq!(events[2], ParserEvent::Bytes(sequence.to_vec()));
            assert_eq!(events[3], ParserEvent::Bytes(b"after".to_vec()));
            assert_eq!(collect_bytes(&events), input);
        }
    }

    #[test]
    fn reset_boundaries_survive_every_byte_split() {
        for (sequence, semantic) in [
            (b"\x1b[2J".as_slice(), ParserEvent::EraseDisplay),
            (b"\x1b[02J".as_slice(), ParserEvent::EraseDisplay),
            (b"\x1b[3J".as_slice(), ParserEvent::EraseScrollback),
            (b"\x1b[03J".as_slice(), ParserEvent::EraseScrollback),
            (b"\x1bc".as_slice(), ParserEvent::HardReset),
        ] {
            for split in 0..=sequence.len() {
                let mut parser = Parser::new();
                let mut events = Vec::new();
                parser.feed(&sequence[..split], &mut events);
                parser.feed(&sequence[split..], &mut events);
                assert_eq!(
                    events.iter().filter(|event| **event == semantic).count(),
                    1,
                    "sequence={sequence:?}, split={split}, events={events:?}"
                );
                assert_eq!(collect_bytes(&events), sequence);
            }
        }
    }

    #[test]
    fn c1_ed2_ed3_are_byte_exact_pre_feed_barriers() {
        for (sequence, semantic) in [
            (b"\x9b2J".as_slice(), ParserEvent::EraseDisplay),
            (b"\x9b02J".as_slice(), ParserEvent::EraseDisplay),
            (b"\x9b3J".as_slice(), ParserEvent::EraseScrollback),
            (b"\x9b03J".as_slice(), ParserEvent::EraseScrollback),
            (b"\xc2\x9b2J".as_slice(), ParserEvent::EraseDisplay),
            (b"\xc2\x9b02J".as_slice(), ParserEvent::EraseDisplay),
            (b"\xc2\x9b3J".as_slice(), ParserEvent::EraseScrollback),
            (b"\xc2\x9b03J".as_slice(), ParserEvent::EraseScrollback),
        ] {
            let input = [b"before".as_slice(), sequence, b"after".as_slice()].concat();
            let mut parser = Parser::new();
            let mut events = Vec::new();
            parser.feed(&input, &mut events);

            assert_eq!(
                events,
                [
                    ParserEvent::Bytes(b"before".to_vec()),
                    semantic,
                    ParserEvent::Bytes(sequence.to_vec()),
                    ParserEvent::Bytes(b"after".to_vec()),
                ],
                "sequence={sequence:?}"
            );
            assert_eq!(collect_bytes(&events), input);
        }
    }

    #[test]
    fn c1_reset_boundaries_survive_every_byte_split() {
        for (sequence, semantic) in [
            (b"\x9b2J".as_slice(), ParserEvent::EraseDisplay),
            (b"\x9b02J".as_slice(), ParserEvent::EraseDisplay),
            (b"\x9b3J".as_slice(), ParserEvent::EraseScrollback),
            (b"\x9b03J".as_slice(), ParserEvent::EraseScrollback),
            (b"\xc2\x9b2J".as_slice(), ParserEvent::EraseDisplay),
            (b"\xc2\x9b02J".as_slice(), ParserEvent::EraseDisplay),
            (b"\xc2\x9b3J".as_slice(), ParserEvent::EraseScrollback),
            (b"\xc2\x9b03J".as_slice(), ParserEvent::EraseScrollback),
        ] {
            for split in 0..=sequence.len() {
                let mut parser = Parser::new();
                let mut events = Vec::new();
                parser.feed(&sequence[..split], &mut events);
                parser.feed(&sequence[split..], &mut events);

                assert_eq!(
                    events.iter().filter(|event| **event == semantic).count(),
                    1,
                    "sequence={sequence:?}, split={split}, events={events:?}"
                );
                assert_eq!(collect_bytes(&events), sequence);

                let barrier = events.iter().position(|event| *event == semantic).unwrap();
                let bytes_before_barrier = collect_bytes(&events[..barrier]);
                assert!(
                    bytes_before_barrier.is_empty() || bytes_before_barrier == b"\xc2",
                    "sequence={sequence:?}, split={split}, events={events:?}"
                );
                assert_eq!(
                    collect_bytes(&events[barrier + 1..]),
                    &sequence[bytes_before_barrier.len()..],
                    "sequence={sequence:?}, split={split}, events={events:?}"
                );
            }
        }
    }

    #[test]
    fn ordinary_c1_csi_is_passed_through_whole_across_every_split() {
        for sequence in [b"\x9b31m".as_slice(), b"\xc2\x9b31m".as_slice()] {
            for split in 0..=sequence.len() {
                let mut parser = Parser::new();
                let mut events = Vec::new();
                parser.feed(&sequence[..split], &mut events);
                parser.feed(&sequence[split..], &mut events);

                assert_eq!(collect_bytes(&events), sequence);
                assert!(events
                    .iter()
                    .all(|event| matches!(event, ParserEvent::Bytes(_))));
                if sequence[0] == 0x9b || split != 1 {
                    assert_eq!(
                        events,
                        [ParserEvent::Bytes(sequence.to_vec())],
                        "sequence={sequence:?}, split={split}"
                    );
                } else {
                    assert_eq!(
                        events,
                        [
                            ParserEvent::Bytes(b"\xc2".to_vec()),
                            ParserEvent::Bytes(b"\x9b31m".to_vec()),
                        ]
                    );
                }
            }
        }
    }

    #[test]
    fn trailing_utf8_c1_lead_is_immediate_passthrough() {
        let mut parser = Parser::new();
        let mut events = Vec::new();
        parser.feed(b"tail\xc2", &mut events);

        assert_eq!(events, [ParserEvent::Bytes(b"tail\xc2".to_vec())]);

        // The suffix window may remember C2 for classification, but it must
        // neither duplicate nor withhold that byte when later text arrives.
        parser.feed(b"x", &mut events);
        assert_eq!(collect_bytes(&events), b"tail\xc2x");
    }

    #[test]
    fn escape_boundaries_clear_the_ground_utf8_tail_before_c1() {
        for boundary in [b"\x1bq".as_slice(), b"\x1bc".as_slice()] {
            let mut parser = Parser::new();
            let mut events = Vec::new();
            parser.feed(b"\xd8", &mut events);

            let suffix = [boundary, b"\x9b2J".as_slice()].concat();
            parser.feed(&suffix, &mut events);

            assert_eq!(
                events
                    .iter()
                    .filter(|event| matches!(event, ParserEvent::EraseDisplay))
                    .count(),
                1,
                "boundary={boundary:?}, events={events:?}"
            );
            assert_eq!(
                collect_bytes(&events),
                [b"\xd8".as_slice(), suffix.as_slice()].concat()
            );
        }
    }

    #[test]
    fn c1_erase_events_reject_nonordinary_lookalikes() {
        for introducer in [b"\x9b".as_slice(), b"\xc2\x9b".as_slice()] {
            for body in [
                b"J".as_slice(),
                b"?2J".as_slice(),
                b">2J".as_slice(),
                b"2;0J".as_slice(),
                b"2:0J".as_slice(),
                b"2 J".as_slice(),
                b"2K".as_slice(),
                b"42949672962J".as_slice(),
                b"?3J".as_slice(),
                b"3;0J".as_slice(),
                b"3:0J".as_slice(),
                b"3 J".as_slice(),
                b"3K".as_slice(),
                b"42949672963J".as_slice(),
            ] {
                let sequence = [introducer, body].concat();
                for split in 0..=sequence.len() {
                    let mut parser = Parser::new();
                    let mut events = Vec::new();
                    parser.feed(&sequence[..split], &mut events);
                    parser.feed(&sequence[split..], &mut events);

                    assert!(events.iter().all(|event| !matches!(
                        event,
                        ParserEvent::EraseDisplay | ParserEvent::EraseScrollback
                    )));
                    assert_eq!(
                        collect_bytes(&events),
                        sequence,
                        "sequence={sequence:?}, split={split}"
                    );
                }
            }
        }
    }

    #[test]
    fn utf8_continuation_9b_in_normal_unicode_is_not_c1() {
        // Cover every continuation position in valid two-, three-, and
        // four-byte UTF-8. The following ASCII deliberately looks like an
        // ED2/ED3 body; none of these 9B bytes is a control introducer.
        for scalar in [
            b"\xd8\x9b".as_slice(),
            b"\xe1\x9b\x80".as_slice(),
            b"\xe2\x82\x9b".as_slice(),
            b"\xf0\x9b\x80\x80".as_slice(),
            b"\xf0\x90\x9b\x80".as_slice(),
            b"\xf0\x90\x80\x9b".as_slice(),
        ] {
            assert!(std::str::from_utf8(scalar).is_ok());
            for body in [b"2J".as_slice(), b"3J".as_slice()] {
                let input = [b"prefix".as_slice(), scalar, body].concat();
                for split in 0..=input.len() {
                    let mut parser = Parser::new();
                    let mut events = Vec::new();
                    parser.feed(&input[..split], &mut events);
                    parser.feed(&input[split..], &mut events);

                    assert!(events.iter().all(|event| !matches!(
                        event,
                        ParserEvent::EraseDisplay | ParserEvent::EraseScrollback
                    )));
                    assert_eq!(
                        collect_bytes(&events),
                        input,
                        "scalar={scalar:?}, body={body:?}, split={split}"
                    );
                }
            }
        }
    }

    #[test]
    fn c1_reset_raw_bytes_precede_suffix_semantics() {
        for (reset, semantic) in [
            (b"\x9b2J".as_slice(), ParserEvent::EraseDisplay),
            (b"\x9b3J".as_slice(), ParserEvent::EraseScrollback),
            (b"\xc2\x9b2J".as_slice(), ParserEvent::EraseDisplay),
            (b"\xc2\x9b3J".as_slice(), ParserEvent::EraseScrollback),
        ] {
            let input = [
                b"prefix".as_slice(),
                reset,
                b"\x1b[c\x1b[?2004htext".as_slice(),
            ]
            .concat();
            let mut parser = Parser::new();
            let mut events = Vec::new();
            parser.feed(&input, &mut events);

            assert_eq!(events[0], ParserEvent::Bytes(b"prefix".to_vec()));
            assert_eq!(events[1], semantic);
            assert_eq!(events[2], ParserEvent::Bytes(reset.to_vec()));
            assert_eq!(
                events[3],
                ParserEvent::KeyboardProtocolQuery(KeyboardProtocolQuery::PrimaryDeviceAttributes)
            );
            assert_eq!(
                events[4],
                ParserEvent::DecsetMode {
                    mode: 2004,
                    set: true
                }
            );
            assert_eq!(collect_bytes(&events), input);
        }
    }

    #[test]
    fn erase_events_reject_nonordinary_and_control_string_lookalikes() {
        let mut parser = Parser::new();
        let mut events = Vec::new();
        // Every form here either has a non-ordinary parameter grammar, a
        // different final, or merely spells "[2J" as inert control-string
        // payload. Feed one byte at a time so no chunk boundary can promote a
        // lookalike into a semantic event.
        for byte in b"\x1b[J\x1b[?2J\x1b[>2J\x1b[2;0J\x1b[2:0J\x1b[2 J\x1b[2K\x1b[42949672962J\x1b[?3J\x1b[3;0J\x1b[3:0J\x1b[3 J\x1b[3K\x1b]0;inside [2J and [3J\x07\x1b_Ga=T;inside [2J and [3J\x1b\\\x1bPqinside [2J and [3J\x1b\\\x1b^inside [2J and [3J\x1b\\\x1bXinside [2J and [3J\x1b\\"
        {
            parser.feed(std::slice::from_ref(byte), &mut events);
        }
        assert!(events.iter().all(|event| !matches!(
            event,
            ParserEvent::EraseDisplay | ParserEvent::EraseScrollback
        )));
    }

    #[test]
    fn reset_raw_bytes_are_an_immediate_barrier_before_suffix_semantics() {
        for (reset, semantic) in [
            (b"\x1bc".as_slice(), ParserEvent::HardReset),
            (b"\x1b[2J".as_slice(), ParserEvent::EraseDisplay),
            (b"\x1b[3J".as_slice(), ParserEvent::EraseScrollback),
        ] {
            let mut parser = Parser::new();
            let mut events = Vec::new();
            let mut input = b"prefix".to_vec();
            input.extend_from_slice(reset);
            input.extend_from_slice(b"\x1b[c\x1b[?2004htext");
            parser.feed(&input, &mut events);

            assert_eq!(events[0], ParserEvent::Bytes(b"prefix".to_vec()));
            assert_eq!(events[1], semantic);
            assert_eq!(events[2], ParserEvent::Bytes(reset.to_vec()));
            assert_eq!(
                events[3],
                ParserEvent::KeyboardProtocolQuery(KeyboardProtocolQuery::PrimaryDeviceAttributes)
            );
            assert_eq!(
                events[4],
                ParserEvent::DecsetMode {
                    mode: 2004,
                    set: true
                }
            );
            assert_eq!(
                collect_bytes(&events),
                [b"prefix".as_slice(), reset, b"\x1b[c\x1b[?2004htext"].concat()
            );
        }
    }

    #[test]
    fn malformed_control_strings_abort_and_reprocess_escape_sequence() {
        for prefix in [
            b"\x1b]133;A".as_slice(),
            b"\x1b_Ga=T;AAAA".as_slice(),
            b"\x1bPqpayload".as_slice(),
            b"\x1b^private-message".as_slice(),
            b"\x1bXsos-payload".as_slice(),
        ] {
            for split in 0..=prefix.len() + 2 {
                let mut parser = Parser::new();
                let mut events = Vec::new();
                let mut input = prefix.to_vec();
                input.extend_from_slice(b"\x1bc\x1b[c");

                let split = split.min(input.len());
                parser.feed(&input[..split], &mut events);
                for byte in &input[split..] {
                    parser.feed(std::slice::from_ref(byte), &mut events);
                }

                assert_eq!(
                    events
                        .iter()
                        .filter(|event| matches!(event, ParserEvent::HardReset))
                        .count(),
                    1,
                    "prefix={prefix:?}, split={split}, events={events:?}"
                );
                assert!(events.iter().all(|event| !matches!(
                    event,
                    ParserEvent::PromptStart | ParserEvent::ApcSequence(_)
                )));
                let reset = events
                    .iter()
                    .position(|event| matches!(event, ParserEvent::HardReset))
                    .unwrap();
                assert_eq!(events[reset + 1], ParserEvent::Bytes(b"\x1bc".to_vec()));
                assert!(matches!(
                    events[reset + 2],
                    ParserEvent::KeyboardProtocolQuery(
                        KeyboardProtocolQuery::PrimaryDeviceAttributes
                    )
                ));
                assert_eq!(collect_bytes(&events), b"\x1bc\x1b[c");
            }
        }
    }

    #[test]
    fn doubled_escape_in_control_string_keeps_second_escape_as_ris_introducer() {
        for prefix in [
            b"\x1b]133;A".as_slice(),
            b"\x1b_Ga=T;AAAA".as_slice(),
            b"\x1bPqpayload".as_slice(),
            b"\x1b^private".as_slice(),
        ] {
            let input = [prefix, b"\x1b\x1bc\x1b[c".as_slice()].concat();
            let mut parser = Parser::new();
            let mut events = Vec::new();
            for byte in &input {
                parser.feed(std::slice::from_ref(byte), &mut events);
            }

            assert!(events.iter().all(|event| !matches!(
                event,
                ParserEvent::PromptStart | ParserEvent::ApcSequence(_)
            )));
            let reset = events
                .iter()
                .position(|event| matches!(event, ParserEvent::HardReset))
                .unwrap();
            assert_eq!(events[reset + 1], ParserEvent::Bytes(b"\x1bc".to_vec()));
            assert!(matches!(
                events[reset + 2],
                ParserEvent::KeyboardProtocolQuery(KeyboardProtocolQuery::PrimaryDeviceAttributes)
            ));
            assert_eq!(collect_bytes(&events), b"\x1bc\x1b[c");
        }
    }

    #[test]
    fn pm_sos_non_st_escape_aborts_before_a_real_ris() {
        for prefix in [b"\x1b^private".as_slice(), b"\x1bXsos".as_slice()] {
            let mut parser = Parser::new();
            let mut events = Vec::new();
            let input = [prefix, b"\x1bq".as_slice(), b"suffix\x1bc".as_slice()].concat();
            for byte in &input {
                parser.feed(std::slice::from_ref(byte), &mut events);
            }

            assert_eq!(events.first(), Some(&ParserEvent::Bytes(b"\x1bq".to_vec())));
            assert_eq!(
                events
                    .iter()
                    .position(|event| matches!(event, ParserEvent::HardReset)),
                Some(events.len() - 2)
            );
            assert_eq!(events.last(), Some(&ParserEvent::Bytes(b"\x1bc".to_vec())));
            assert_eq!(collect_bytes(&events), b"\x1bqsuffix\x1bc");
        }
    }

    #[test]
    fn bel_terminates_only_osc_not_apc_or_dcs() {
        let mut parser = Parser::new();
        let mut events = Vec::new();
        parser.feed(b"\x1b]133;A\x07", &mut events);
        assert!(matches!(&events[..], [ParserEvent::PromptStart]));

        events.clear();
        parser.feed(b"\x1b_Ga=T;A\x07B", &mut events);
        assert!(events.is_empty());
        parser.feed(b"\x1b\\", &mut events);
        assert_eq!(events, [ParserEvent::ApcSequence(b"Ga=T;A\x07B".to_vec())]);

        events.clear();
        parser.feed(b"\x1bPqA\x07B", &mut events);
        assert!(events.is_empty());
        parser.feed(b"\x1b\\", &mut events);
        assert_eq!(collect_bytes(&events), b"\x1bPqA\x07B\x1b\\");
    }

    #[test]
    fn mouse_modes_keep_independent_flags_and_priority_across_order_and_reset() {
        let modes = [9, 1000, 1002, 1003, 1005, 1015, 1006];
        for mask in 0_u8..128 {
            for reverse in [false, true] {
                let mut parser = Parser::new();
                let mut events = Vec::new();
                for index in 0..modes.len() {
                    let index = if reverse {
                        modes.len() - 1 - index
                    } else {
                        index
                    };
                    if mask & (1 << index) != 0 {
                        parser.feed(format!("\x1b[?{}h", modes[index]).as_bytes(), &mut events);
                    }
                }
                let expected_tracking = |bits: u8| {
                    if bits & 8 != 0 {
                        MouseMode::AnyEvent
                    } else if bits & 4 != 0 {
                        MouseMode::ButtonEvent
                    } else if bits & 2 != 0 {
                        MouseMode::Normal
                    } else if bits & 1 != 0 {
                        MouseMode::X10
                    } else {
                        MouseMode::None
                    }
                };
                let expected_encoding = |bits: u8| {
                    if bits & 64 != 0 {
                        MouseEncoding::Sgr
                    } else if bits & 32 != 0 {
                        MouseEncoding::Urxvt
                    } else if bits & 16 != 0 {
                        MouseEncoding::Utf8
                    } else {
                        MouseEncoding::Default
                    }
                };
                assert_eq!(parser.mouse_mode(), expected_tracking(mask));
                assert_eq!(parser.mouse_encoding(), expected_encoding(mask));
                // Turning off each enabled or already-disabled flag must
                // preserve every other mode, including the next fallback.
                let mut remaining = mask;
                for (index, mode) in modes.into_iter().enumerate() {
                    parser.feed(format!("\x1b[?{mode}l").as_bytes(), &mut events);
                    remaining &= !(1 << index);
                    assert_eq!(parser.mouse_mode(), expected_tracking(remaining));
                    assert_eq!(parser.mouse_encoding(), expected_encoding(remaining));
                }
            }
        }
    }

    #[test]
    fn compound_mouse_modes_and_ris_preserve_passthrough_and_reset_all_flags() {
        let mut parser = Parser::new();
        let mut events = Vec::new();
        let wire = b"\x1b[?1006;1005;1015;1003;1000;9h\x1b[?1002l";
        parser.feed(wire, &mut events);
        assert_eq!(collect_bytes(&events), wire);
        assert_eq!(parser.mouse_mode(), MouseMode::AnyEvent);
        assert_eq!(parser.mouse_encoding(), MouseEncoding::Sgr);
        parser.feed(b"\x1bc\x1b[?1006l\x1b[?1003l", &mut events);
        assert_eq!(parser.mouse_mode(), MouseMode::None);
        assert_eq!(parser.mouse_encoding(), MouseEncoding::Default);
    }

    #[test]
    fn ris_resets_parser_private_mode_snooping() {
        let mut parser = Parser::new();
        let mut events = Vec::new();
        parser.feed(b"\x1b[?2004;1003;1006;1004h", &mut events);
        assert!(parser.bracketed_paste());
        assert_eq!(parser.mouse_mode(), MouseMode::AnyEvent);
        assert_eq!(parser.mouse_encoding(), MouseEncoding::Sgr);
        assert!(parser.focus_events());

        events.clear();
        parser.feed(b"\x1bc", &mut events);
        assert!(!parser.bracketed_paste());
        assert_eq!(parser.mouse_mode(), MouseMode::None);
        assert_eq!(parser.mouse_encoding(), MouseEncoding::Default);
        assert!(!parser.focus_events());
        assert_eq!(events[0], ParserEvent::HardReset);
    }

    #[test]
    fn oversized_osc_is_discarded_and_recovers_from_split_st() {
        let mut parser = Parser::new();
        let mut events = Vec::new();
        parser.feed(b"\x1b]0;", &mut events);

        let chunk = vec![b'x'; 64 * 1024];
        for _ in 0..=(MAX_OSC_PAYLOAD_BYTES / chunk.len()) {
            parser.feed(&chunk, &mut events);
        }

        assert!(events.is_empty());
        assert!(matches!(parser.state, State::OscDiscard));

        parser.feed(b"\x1b", &mut events);
        assert!(matches!(parser.state, State::OscDiscardEsc));
        // A non-ST escape aborts the oversized string and is reinterpreted as
        // a new ESC sequence. `ESC X` starts SOS, so use a harmless escape
        // final here before checking ordinary text becomes visible again.
        parser.feed(b"qvisible", &mut events);

        assert!(matches!(parser.state, State::Ground));
        assert_eq!(collect_bytes(&events), b"\x1bqvisible");
    }

    #[test]
    fn erase_parameter_past_u32_saturates_away_from_semantic_events() {
        for (sequence, semantic) in [
            (b"\x1b[42949672962J".as_slice(), ParserEvent::EraseDisplay),
            (
                b"\x1b[42949672963J".as_slice(),
                ParserEvent::EraseScrollback,
            ),
        ] {
            let mut parser = Parser::new();
            let mut events = Vec::new();
            // The accumulator must saturate, never wrap onto a recognized
            // value and fire a side effect VTE would not interpret as ED2/ED3.
            parser.feed(sequence, &mut events);
            assert!(events.iter().all(|event| *event != semantic));
            assert_eq!(collect_bytes(&events), sequence);
        }
    }

    #[test]
    fn osc_aborted_by_esc_bel_drops_the_payload_and_passes_both_bytes_through() {
        let mut parser = Parser::new();
        let mut events = Vec::new();
        // ESC BEL is not ST: the incomplete OSC must be aborted without any
        // handle_osc effect (no OSC 133 mark), and the raw ESC BEL bytes are
        // reinterpreted as an ordinary escape sequence for the terminal.
        parser.feed(b"\x1b]133;A\x1b\x07after", &mut events);
        assert!(events
            .iter()
            .all(|event| !matches!(event, ParserEvent::PromptStart)));
        assert!(matches!(parser.state, State::Ground));
        assert_eq!(collect_bytes(&events), b"\x1b\x07after");
    }

    #[test]
    fn oversized_apc_and_dcs_abort_and_reprocess_a_non_st_escape() {
        let mut parser = Parser::new();
        let mut events = Vec::new();
        parser.feed(b"\x1b_Ga=T;", &mut events);
        let chunk = vec![b'A'; 64 * 1024];
        for _ in 0..=(MAX_APC_PAYLOAD_BYTES / chunk.len()) {
            parser.feed(&chunk, &mut events);
        }
        assert!(matches!(parser.state, State::ApcDiscard));
        parser.feed(b"\x1b", &mut events);
        assert!(matches!(parser.state, State::ApcDiscardEsc));
        // A non-ST escape aborts the oversized string and is reinterpreted as
        // a new ESC sequence; ordinary text becomes visible again.
        parser.feed(b"qvisible", &mut events);
        assert!(matches!(parser.state, State::Ground));
        assert_eq!(collect_bytes(&events), b"\x1bqvisible");
        assert!(events
            .iter()
            .all(|event| !matches!(event, ParserEvent::ApcSequence(_))));

        let mut parser = Parser::new();
        let mut events = Vec::new();
        parser.feed(b"\x1bPq", &mut events);
        let chunk = vec![b'x'; 8 * 1024];
        for _ in 0..=(MAX_DCS_PAYLOAD_BYTES / chunk.len()) {
            parser.feed(&chunk, &mut events);
        }
        assert!(matches!(parser.state, State::DcsDiscard));
        parser.feed(b"\x1b", &mut events);
        assert!(matches!(parser.state, State::DcsDiscardEsc));
        parser.feed(b"qvisible", &mut events);
        assert!(matches!(parser.state, State::Ground));
        assert_eq!(collect_bytes(&events), b"\x1bqvisible");
    }

    #[test]
    fn osc_9_and_777_become_bounded_notification_events() {
        let mut parser = Parser::new();
        let mut events = Vec::new();
        parser.feed(b"\x1b]9;build finished\x07", &mut events);
        assert!(matches!(
            &events[..],
            [ParserEvent::Notification { title: None, body }] if body == "build finished"
        ));

        events.clear();
        parser.feed(b"\x1b]777;notify;CI;tests green\x1b\\", &mut events);
        assert!(matches!(
            &events[..],
            [ParserEvent::Notification { title: Some(title), body }]
                if title == "CI" && body == "tests green"
        ));

        // Control and visual-formatting characters are made visible and fields
        // are capped, so a hostile app cannot inject invisible structure into
        // the notification daemon or trusted-looking desktop chrome.
        events.clear();
        let long = "x".repeat(2 * MAX_NOTIFICATION_CHARS);
        parser.feed(b"\x1b]9;evil\ttab\x1b\\", &mut events);
        parser.feed(
            "\x1b]9;left\u{202e}right\u{00a0}tail\x07".as_bytes(),
            &mut events,
        );
        parser.feed(
            "\x1b]9;anchor\u{fff9}separator\u{fffa}terminator\u{fffb}\x07".as_bytes(),
            &mut events,
        );
        parser.feed(format!("\x1b]9;{long}\x07").as_bytes(), &mut events);
        let bodies: Vec<&String> = events
            .iter()
            .filter_map(|event| match event {
                ParserEvent::Notification { body, .. } => Some(body),
                _ => None,
            })
            .collect();
        assert_eq!(bodies[0], "evil\u{fffd}tab");
        assert_eq!(bodies[1], "left\u{fffd}right\u{fffd}tail");
        assert_eq!(
            bodies[2],
            "anchor\u{fffd}separator\u{fffd}terminator\u{fffd}"
        );
        assert_eq!(bodies[3].chars().count(), MAX_NOTIFICATION_CHARS);

        // Empty notifications and non-notify OSC 777 subcommands emit nothing.
        events.clear();
        parser.feed(b"\x1b]9; \x07\x1b]777;other;a;b\x07", &mut events);
        assert!(events
            .iter()
            .all(|event| !matches!(event, ParserEvent::Notification { .. })));
    }

    #[test]
    fn dynamic_color_set_and_reset_emit_events_and_pass_through() {
        let mut parser = Parser::new();
        let mut events = Vec::new();
        parser.feed(b"\x1b]11;#1e1e2e\x07", &mut events);
        assert!(matches!(
            &events[..],
            [
                ParserEvent::ColorSet { kind: ColorKind::Background, spec },
                ParserEvent::Bytes(bytes),
            ] if spec == "#1e1e2e" && bytes.starts_with(b"\x1b]11;#1e1e2e")
        ));

        // Named specs forward verbatim for the app's toolkit to parse.
        events.clear();
        parser.feed(b"\x1b]10;rebeccapurple\x1b\\", &mut events);
        assert!(matches!(
            &events[..],
            [ParserEvent::ColorSet { kind: ColorKind::Foreground, spec }, ParserEvent::Bytes(_)]
                if spec == "rebeccapurple"
        ));

        // Queries stay consumed semantic events, exactly as before.
        events.clear();
        parser.feed(b"\x1b]12;?\x07", &mut events);
        assert!(matches!(
            &events[..],
            [ParserEvent::ColorQuery(ColorKind::Cursor)]
        ));

        // Resets emit the event and still pass through to the live view.
        events.clear();
        parser.feed(b"\x1b]110\x07\x1b]112;\x07", &mut events);
        let resets: Vec<&ColorKind> = events
            .iter()
            .filter_map(|event| match event {
                ParserEvent::ColorReset(kind) => Some(kind),
                _ => None,
            })
            .collect();
        assert_eq!(resets, [&ColorKind::Foreground, &ColorKind::Cursor]);
        assert_eq!(
            events
                .iter()
                .filter(|event| matches!(event, ParserEvent::Bytes(_)))
                .count(),
            2
        );

        // Oversized specs only pass through — no semantic event.
        events.clear();
        let long = "x".repeat(MAX_COLOR_SPEC_CHARS + 1);
        parser.feed(format!("\x1b]11;{long}\x07").as_bytes(), &mut events);
        assert!(events
            .iter()
            .all(|event| !matches!(event, ParserEvent::ColorSet { .. })));
        assert!(matches!(&events[..], [ParserEvent::Bytes(_)]));
    }

    #[test]
    fn oversized_apc_is_discarded_and_recovers_at_st() {
        let mut parser = Parser::new();
        let mut events = Vec::new();
        parser.feed(b"\x1b_Ga=T;", &mut events);

        let chunk = vec![b'A'; 64 * 1024];
        for _ in 0..=(MAX_APC_PAYLOAD_BYTES / chunk.len()) {
            parser.feed(&chunk, &mut events);
        }

        assert!(events.is_empty());
        assert!(matches!(parser.state, State::ApcDiscard));

        parser.feed(b"\x07still-hidden", &mut events);
        assert!(matches!(parser.state, State::ApcDiscard));
        parser.feed(b"\x1b\\visible", &mut events);
        assert!(matches!(parser.state, State::Ground));
        assert_eq!(collect_bytes(&events), b"visible");
        assert!(events
            .iter()
            .all(|event| !matches!(event, ParserEvent::ApcSequence(_))));
    }

    #[test]
    fn csi_not_split_across_feeds() {
        let mut p = Parser::new();
        let mut events = Vec::new();
        p.feed(b"\x1b[3", &mut events);
        p.feed(b"1m", &mut events);
        let bytes_events: Vec<&Vec<u8>> = events
            .iter()
            .filter_map(|e| match e {
                ParserEvent::Bytes(b) => Some(b),
                _ => None,
            })
            .collect();
        assert_eq!(bytes_events.len(), 1, "CSI must not be split into pieces");
        assert_eq!(bytes_events[0].as_slice(), b"\x1b[31m");
    }

    #[test]
    fn alt_screen_enter_leave_emitted_and_stripped() {
        let mut p = Parser::new();
        let mut events = Vec::new();
        p.feed(b"\x1b[?1049h\x1b[?1049l", &mut events);
        assert!(matches!(events[0], ParserEvent::AltScreenEnter(1049)));
        assert!(matches!(events[1], ParserEvent::AltScreenLeave(1049)));
        assert!(collect_bytes(&events).is_empty());
    }

    #[test]
    fn legacy_alt_screen_modes_keep_their_exact_mode() {
        let mut p = Parser::new();
        let mut events = Vec::new();
        p.feed(b"\x1b[?47h\x1b[?47l\x1b[?1047h\x1b[?1047l", &mut events);
        assert!(matches!(events[0], ParserEvent::AltScreenEnter(47)));
        assert!(matches!(events[1], ParserEvent::AltScreenLeave(47)));
        assert!(matches!(events[2], ParserEvent::AltScreenEnter(1047)));
        assert!(matches!(events[3], ParserEvent::AltScreenLeave(1047)));
        assert!(collect_bytes(&events).is_empty());
    }

    #[test]
    fn dcs_is_passed_through_not_dropped() {
        // A DCS sixel sequence: ESC P q ... ESC \. The whole thing should
        // appear verbatim in the Bytes stream so the active VTE can render it.
        let mut p = Parser::new();
        let mut events = Vec::new();
        p.feed(b"before\x1bPq#0;2;0;0;0!100~-\x1b\\after", &mut events);
        let bytes = collect_bytes(&events);
        // The plain "before" and "after" survive, and the DCS round-trips.
        assert!(bytes.windows(6).any(|w| w == b"before"));
        assert!(bytes.windows(5).any(|w| w == b"after"));
        assert!(bytes.windows(3).any(|w| w == b"\x1bPq"));
        assert!(bytes.windows(2).any(|w| w == b"\x1b\\"));
    }

    #[test]
    fn oversized_dcs_is_discarded_until_its_actual_terminator() {
        let mut p = Parser::new();
        let mut events = Vec::new();
        p.feed(b"before\x1bPq", &mut events);
        let chunk = vec![b'x'; 8 * 1024];
        for _ in 0..=(MAX_DCS_PAYLOAD_BYTES / chunk.len()) {
            p.feed(&chunk, &mut events);
        }
        assert!(matches!(p.state, State::DcsDiscard));

        p.feed(b"must-not-leak\x1b", &mut events);
        assert!(matches!(p.state, State::DcsDiscardEsc));
        p.feed(b"\\after", &mut events);
        assert_eq!(collect_bytes(&events), b"beforeafter");
    }

    #[test]
    fn pm_st_does_not_leak_backslash() {
        let mut p = Parser::new();
        let mut events = Vec::new();
        p.feed(b"before\x1b^ignored\x1b\\after", &mut events);
        assert_eq!(collect_bytes(&events), b"beforeafter");
    }

    #[test]
    fn osc_color_queries_emit_events() {
        let mut p = Parser::new();
        let mut events = Vec::new();
        p.feed(
            b"\x1b]11;?\x07\x1b]10;?\x07\x1b]12;?\x1b\\\x1b]4;5;?\x07",
            &mut events,
        );
        let kinds: Vec<_> = events
            .iter()
            .filter_map(|e| match e {
                ParserEvent::ColorQuery(k) => Some(*k),
                _ => None,
            })
            .collect();
        assert_eq!(
            kinds,
            vec![
                ColorKind::Background,
                ColorKind::Foreground,
                ColorKind::Cursor,
                ColorKind::Palette(5),
            ]
        );
    }

    #[test]
    fn keyboard_protocol_queries_emit_events() {
        let mut p = Parser::new();
        let mut events = Vec::new();
        // kitty flag query, modifyOtherKeys query, primary & secondary DA.
        p.feed(b"\x1b[?u\x1b[?4m\x1b[c\x1b[>c", &mut events);
        let qs: Vec<_> = events
            .iter()
            .filter_map(|e| match e {
                ParserEvent::KeyboardProtocolQuery(q) => Some(*q),
                _ => None,
            })
            .collect();
        assert_eq!(
            qs,
            vec![
                KeyboardProtocolQuery::KittyQuery,
                KeyboardProtocolQuery::ModifyOtherKeysQuery,
                KeyboardProtocolQuery::PrimaryDeviceAttributes,
                KeyboardProtocolQuery::SecondaryDeviceAttributes,
            ]
        );
    }

    #[test]
    fn kitty_keyboard_stack_operations_emit_events_and_pass_through() {
        let mut p = Parser::new();
        let mut events = Vec::new();
        // codex/kimi push 7 and query; a pop, a bare pop, and the three set modes.
        p.feed(
            b"\x1b[>7u\x1b[?u\x1b[<2u\x1b[<u\x1b[=1;2u\x1b[=5;3u\x1b[=3u\x1b[>u",
            &mut events,
        );
        let ops: Vec<_> = events
            .iter()
            .filter_map(|e| match e {
                ParserEvent::KittyKeyboard(op) => Some(*op),
                _ => None,
            })
            .collect();
        assert_eq!(
            ops,
            vec![
                KittyKeyboardOp::Push(7),
                KittyKeyboardOp::Pop(2),
                KittyKeyboardOp::Pop(0),
                KittyKeyboardOp::Set { flags: 1, mode: 2 },
                KittyKeyboardOp::Set { flags: 5, mode: 3 },
                KittyKeyboardOp::Set { flags: 3, mode: 1 },
                KittyKeyboardOp::Push(0),
            ]
        );
        assert!(events.iter().any(|e| matches!(
            e,
            ParserEvent::KeyboardProtocolQuery(KeyboardProtocolQuery::KittyQuery)
        )));
        // Every sequence still reaches the surface verbatim.
        let passed: Vec<u8> = events
            .iter()
            .filter_map(|e| match e {
                ParserEvent::Bytes(b) => Some(b.clone()),
                _ => None,
            })
            .flatten()
            .collect();
        assert!(passed.windows(5).any(|w| w == b"\x1b[>7u"));
        assert!(passed.windows(7).any(|w| w == b"\x1b[=1;2u"));
    }

    #[test]
    fn kitty_keyboard_parameters_saturate_instead_of_wrapping() {
        let mut p = Parser::new();
        let mut events = Vec::new();
        p.feed(b"\x1b[>99999999999999999999u\x1b[<300u", &mut events);
        let ops: Vec<_> = events
            .iter()
            .filter_map(|e| match e {
                ParserEvent::KittyKeyboard(op) => Some(*op),
                _ => None,
            })
            .collect();
        assert_eq!(
            ops,
            vec![KittyKeyboardOp::Push(255), KittyKeyboardOp::Pop(255)]
        );
    }

    #[test]
    fn da1_da2_da3_emit_distinct_events() {
        let mut p = Parser::new();
        let mut events = Vec::new();
        p.feed(b"\x1b[0c\x1b[>0c\x1b[=0c", &mut events);
        let qs: Vec<_> = events
            .iter()
            .filter_map(|e| match e {
                ParserEvent::KeyboardProtocolQuery(q) => Some(*q),
                _ => None,
            })
            .collect();
        assert_eq!(
            qs,
            vec![
                KeyboardProtocolQuery::PrimaryDeviceAttributes,
                KeyboardProtocolQuery::SecondaryDeviceAttributes,
                KeyboardProtocolQuery::TertiaryDeviceAttributes,
            ]
        );
    }

    #[test]
    fn osc133_command_lifecycle() {
        let mut p = Parser::new();
        let mut events = Vec::new();
        p.feed(b"\x1b]133;A\x07\x1b]133;C\x07\x1b]133;D;0\x07", &mut events);
        let kinds: Vec<_> = events
            .iter()
            .map(|e| match e {
                ParserEvent::PromptStart => "A",
                ParserEvent::CommandStart(_) => "C",
                ParserEvent::CommandEnd { .. } => "D",
                _ => "?",
            })
            .collect();
        assert_eq!(kinds, vec!["A", "C", "D"]);

        // The bare FinalTerm form carries no metadata, and that must stay
        // distinguishable from a shell whose metadata failed to decode.
        assert_eq!(events[1], ParserEvent::CommandStart(CommandMeta::default()));
        assert_eq!(
            events[2],
            ParserEvent::CommandEnd {
                exit: Some(0),
                meta: CommandMeta::default(),
            }
        );
    }

    #[test]
    fn private_agent_integration_ready_marker_is_strict_and_hidden() {
        let token = "0123456789abcdef0123456789abcdef";
        assert_eq!(
            only_event(format!("\x1b]7771;{token}\x07").as_bytes()),
            ParserEvent::AgentIntegrationReady(token.to_string())
        );

        for invalid in [
            "short",
            "0123456789abcdef0123456789abcdeg",
            "0123456789abcdef0123456789abcdef0",
        ] {
            let mut parser = Parser::new();
            let mut events = Vec::new();
            parser.feed(format!("\x1b]7771;{invalid}\x07").as_bytes(), &mut events);
            assert!(events.is_empty(), "accepted invalid token {invalid:?}");
        }
    }

    fn only_event(bytes: &[u8]) -> ParserEvent {
        let mut p = Parser::new();
        let mut events = Vec::new();
        p.feed(bytes, &mut events);
        assert_eq!(events.len(), 1, "{events:?}");
        events.pop().expect("one event")
    }

    /// Twin test: the byte literal is jsh's own, copied from the assertion in
    /// `jsh/src/osc.rs` that pins what `command_output_start_packet` emits. If
    /// either end changes the packet format, this reddens.
    #[test]
    fn osc133_start_decodes_the_packet_jsh_actually_emits() {
        let event = only_event(
            b"\x1b]133;C;id=jsh-1;session_id=session-1;seq=7;started_at_ms=11;cmd_truncated=1;cwd_url=%2Ftmp\x07",
        );
        assert_eq!(
            event,
            ParserEvent::CommandStart(CommandMeta {
                id: Some("jsh-1".to_string()),
                session_id: Some("session-1".to_string()),
                seq: Some(7),
                started_at_ms: Some(11),
                command: None,
                cwd: Some("/tmp".to_string()),
                duration_ms: None,
                // The shell had a command line and dropped it for size. Telling
                // that apart from "sends no metadata" is the whole point.
                command_truncated: true,
            })
        );
    }

    #[test]
    fn osc133_lifecycle_identity_is_complete_order_independent_and_packet_local() {
        for fields in [
            "id=jsh-1;session_id=session-1;seq=7;started_at_ms=11",
            "started_at_ms=11;seq=7;session_id=session-1;id=jsh-1",
            "seq=7;id=jsh-1;started_at_ms=11;session_id=session-1",
        ] {
            let packet = format!("\x1b]133;C;{fields}\x07");
            let ParserEvent::CommandStart(meta) = only_event(packet.as_bytes()) else {
                panic!("expected CommandStart");
            };
            let lifecycle = crate::execution_journal::ExecutionLifecycle::from_command_meta(&meta)
                .expect("complete jsh lifecycle");
            assert_eq!(lifecycle.id(), "jsh-1", "fields={fields}");
            assert_eq!(lifecycle.session_id(), "session-1", "fields={fields}");
            assert_eq!(lifecycle.seq(), 7, "fields={fields}");
            assert_eq!(lifecycle.started_at_ms(), 11, "fields={fields}");
        }

        let mut parser = Parser::new();
        let mut events = Vec::new();
        parser.feed(
            b"\x1b]133;C;id=jsh-1;session_id=session-1;seq=7;started_at_ms=11\x07\x1b]133;C;id=jsh-2\x07",
            &mut events,
        );
        let ParserEvent::CommandStart(second) = &events[1] else {
            panic!("expected second CommandStart");
        };
        assert_eq!(second.id.as_deref(), Some("jsh-2"));
        assert_eq!(second.session_id, None);
        assert_eq!(second.seq, None);
        assert_eq!(second.started_at_ms, None);
        assert!(
            crate::execution_journal::ExecutionLifecycle::from_command_meta(second).is_none(),
            "one packet must not inherit another packet's identity slots"
        );

        let ParserEvent::CommandEnd { meta, .. } =
            only_event(b"\x1b]133;D;0;id=jsh-1;session_id=session-1;seq=7;started_at_ms=11\x07")
        else {
            panic!("expected CommandEnd");
        };
        assert_eq!(meta.id.as_deref(), Some("jsh-1"));
        assert!(
            crate::execution_journal::ExecutionLifecycle::from_command_meta(&meta).is_none(),
            "a D packet cannot mint a Start capability"
        );
    }

    #[test]
    fn osc133_lifecycle_identity_rejects_missing_duplicate_alias_and_invalid_slots() {
        for fields in [
            "id=jsh-1;session_id=session-1;seq=7",
            "id=jsh-1;session_id=session-1;started_at_ms=11",
            "id=jsh-1;seq=7;started_at_ms=11",
            "session_id=session-1;seq=7;started_at_ms=11",
            "id=jsh-1;session=session-1;sequence=7;start_time_ms=11",
            "id=jsh-1;session_id=;seq=7;started_at_ms=11",
            "id=jsh-1;session_id=bad%2Fsession;seq=7;started_at_ms=11",
            "id=jsh-1;session_id=session-1;seq=-1;started_at_ms=11",
            "id=jsh-1;session_id=session-1;seq=%207;started_at_ms=11",
            "id=jsh-1;session_id=session-1;seq=7;started_at_ms=18446744073709551616",
        ] {
            let packet = format!("\x1b]133;C;{fields}\x07");
            let ParserEvent::CommandStart(meta) = only_event(packet.as_bytes()) else {
                panic!("expected CommandStart");
            };
            assert!(
                crate::execution_journal::ExecutionLifecycle::from_command_meta(&meta).is_none(),
                "fields={fields}"
            );
        }

        for duplicate in [
            "id=jsh-1;id=jsh-1;session_id=session-1;seq=7;started_at_ms=11",
            "id=jsh-1;session_id=session-1;session_id=session-1;seq=7;started_at_ms=11",
            "id=jsh-1;session_id=session-1;seq=7;seq=7;started_at_ms=11",
            "id=jsh-1;session_id=session-1;seq=7;started_at_ms=11;started_at_ms=11",
        ] {
            let packet = format!("\x1b]133;C;{duplicate}\x07");
            let ParserEvent::CommandStart(meta) = only_event(packet.as_bytes()) else {
                panic!("expected CommandStart");
            };
            assert!(
                crate::execution_journal::ExecutionLifecycle::from_command_meta(&meta).is_none(),
                "duplicate={duplicate}"
            );
        }

        let maximum_session = "s".repeat(MAX_OSC133_SESSION_ID_BYTES);
        let packet = format!(
            "\x1b]133;C;id=jsh-1;session_id={maximum_session};seq={};started_at_ms={}\x07",
            u64::MAX,
            u64::MAX
        );
        let ParserEvent::CommandStart(meta) = only_event(packet.as_bytes()) else {
            panic!("expected CommandStart");
        };
        let lifecycle = crate::execution_journal::ExecutionLifecycle::from_command_meta(&meta)
            .expect("exact maxima remain valid");
        assert_eq!(lifecycle.session_id(), maximum_session);
        assert_eq!(lifecycle.seq(), u64::MAX);
        assert_eq!(lifecycle.started_at_ms(), u64::MAX);

        let oversized_session = "s".repeat(MAX_OSC133_SESSION_ID_BYTES + 1);
        let packet = format!(
            "\x1b]133;C;id=jsh-1;session_id={oversized_session};seq=7;started_at_ms=11\x07"
        );
        let ParserEvent::CommandStart(meta) = only_event(packet.as_bytes()) else {
            panic!("expected CommandStart");
        };
        assert!(crate::execution_journal::ExecutionLifecycle::from_command_meta(&meta).is_none());
    }

    #[test]
    fn osc133_end_keeps_the_positional_exit_and_the_metadata() {
        let event =
            only_event(b"\x1b]133;D;127;id=jsh-2;duration_ms=42;cwd_url=%2Ftmp%2Fa%3Bb\x07");
        assert_eq!(
            event,
            ParserEvent::CommandEnd {
                exit: Some(127),
                meta: CommandMeta {
                    id: Some("jsh-2".to_string()),
                    session_id: None,
                    seq: None,
                    started_at_ms: None,
                    command: None,
                    // `;` is percent-escaped by jsh precisely so it cannot forge
                    // a field boundary; it must come back as data.
                    cwd: Some("/tmp/a;b".to_string()),
                    duration_ms: Some(42),
                    command_truncated: false,
                },
            }
        );
    }

    #[test]
    fn osc133_end_accepts_each_family_exit_status_spelling() {
        for key in ["exit", "exit_code", "exit_status"] {
            let packet = format!("\x1b]133;D;{key}=7;id=jsh-2;duration_ms=42;cwd_url=%2Ftmp\x07");
            let ParserEvent::CommandEnd { exit, meta } = only_event(packet.as_bytes()) else {
                panic!("expected CommandEnd");
            };
            assert_eq!(exit, Some(7), "key={key}");
            assert_eq!(meta.id.as_deref(), Some("jsh-2"), "key={key}");
            assert_eq!(meta.duration_ms, Some(42), "key={key}");
            assert_eq!(meta.cwd.as_deref(), Some("/tmp"), "key={key}");
        }

        let ParserEvent::CommandEnd { exit, meta } =
            only_event(b"\x1b]133;D;id=jsh-2;7;duration_ms=42\x07")
        else {
            panic!("expected CommandEnd");
        };
        assert_eq!(exit, Some(7));
        assert_eq!(meta.id.as_deref(), Some("jsh-2"));
        assert_eq!(meta.duration_ms, Some(42));

        let ParserEvent::CommandEnd { exit, .. } =
            only_event(b"\x1b]133;D;unknown-extension;exit_code=%20;exit_status=7\x07")
        else {
            panic!("expected CommandEnd");
        };
        assert_eq!(
            exit, None,
            "two explicit aliases stay ambiguous even when one is malformed"
        );

        let ParserEvent::CommandEnd { exit, .. } =
            only_event(b"\x1b]133;D;unknown-extension;exit_code=%207%20\x07")
        else {
            panic!("expected CommandEnd");
        };
        assert_eq!(exit, None, "numeric fields are not percent-decoded");

        let ParserEvent::CommandEnd { exit, .. } =
            only_event(b"\x1b]133;D;unknown-extension;exit_code= 7 \x07")
        else {
            panic!("expected CommandEnd");
        };
        assert_eq!(exit, Some(7));
    }

    #[test]
    fn osc133_repeated_exit_status_slots_degrade_only_the_outcome() {
        for fields in [
            "0;7",
            "0;exit=7",
            "exit=0;exit_code=7",
            "exit_code=0;exit_status=7",
            "exit_status=0;7",
        ] {
            let packet = format!("\x1b]133;D;{fields};id=jsh-2;duration_ms=42;cwd_url=%2Ftmp\x07");
            let ParserEvent::CommandEnd { exit, meta } = only_event(packet.as_bytes()) else {
                panic!("expected CommandEnd");
            };
            assert_eq!(exit, None, "fields={fields}");
            assert_eq!(meta.id.as_deref(), Some("jsh-2"), "fields={fields}");
            assert_eq!(meta.duration_ms, Some(42), "fields={fields}");
            assert_eq!(meta.cwd.as_deref(), Some("/tmp"), "fields={fields}");
        }

        let ParserEvent::CommandEnd { exit, meta } =
            only_event(b"\x1b]133;D;exit_code=not-a-number;id=jsh-2;duration_ms=42\x07")
        else {
            panic!("expected CommandEnd");
        };
        assert_eq!(exit, None);
        assert_eq!(meta.id.as_deref(), Some("jsh-2"));
        assert_eq!(meta.duration_ms, Some(42));

        let ParserEvent::CommandEnd { exit, .. } =
            only_event(b"\x1b]133;D;0;unknown-extension;id=jsh-2\x07")
        else {
            panic!("expected CommandEnd");
        };
        assert_eq!(exit, Some(0), "an unknown bare extension is not a status");
    }

    #[test]
    fn osc133_duration_aliases_follow_the_family_numeric_grammar() {
        for key in ["duration", "duration_ms"] {
            let packet = format!("\x1b]133;D;0;{key}= 42 ;id=jsh-2\x07");
            let ParserEvent::CommandEnd { exit, meta } = only_event(packet.as_bytes()) else {
                panic!("expected CommandEnd");
            };
            assert_eq!(exit, Some(0), "key={key}");
            assert_eq!(meta.duration_ms, Some(42), "key={key}");
            assert_eq!(meta.id.as_deref(), Some("jsh-2"), "key={key}");
        }

        for invalid in ["%2042", "-1", "18446744073709551616"] {
            let packet = format!("\x1b]133;D;0;duration_ms={invalid};id=jsh-2\x07");
            let ParserEvent::CommandEnd { exit, meta } = only_event(packet.as_bytes()) else {
                panic!("expected CommandEnd");
            };
            assert_eq!(exit, Some(0), "value={invalid}");
            assert_eq!(meta.duration_ms, None, "value={invalid}");
            assert_eq!(meta.id.as_deref(), Some("jsh-2"), "value={invalid}");
        }
    }

    #[test]
    fn osc133_start_decodes_a_percent_encoded_command_line() {
        let event = only_event(
            b"\x1b]133;C;id=jsh-3;cmdline_url=printf%20%27a%3Bb%2Bc%27%0A%E9%9B%AA;cwd_url=%2Ftmp\x07",
        );
        let ParserEvent::CommandStart(meta) = event else {
            panic!("expected CommandStart");
        };
        // This is the exact packet shape jsh emits for a multiline command.
        // Newline is structural shell syntax, not terminal framing (it was
        // percent-encoded on the wire), so the block/journal path must retain
        // it. Display and replay remain separate sanitized/reviewed surfaces.
        assert_eq!(meta.command.as_deref(), Some("printf 'a;b+c'\n雪"));
        assert_eq!(meta.cwd.as_deref(), Some("/tmp"));
    }

    #[test]
    fn osc133_repeated_aliases_invalidate_the_semantic_slot() {
        let ParserEvent::CommandStart(meta) = only_event(
            b"\x1b]133;C;id=first;execution_id=second;cmdline_url=true;command=false;cwd_url=%2Fa;cwd=%2Fb\x07",
        ) else {
            panic!("expected CommandStart");
        };
        assert_eq!(meta.id, None, "a correlation id must never be last-wins");
        assert_eq!(meta.command, None, "a command must never be last-wins");
        assert_eq!(meta.cwd, None, "a cwd must never be last-wins");

        let ParserEvent::CommandEnd { meta, .. } = only_event(
            b"\x1b]133;D;0;duration_ms=1;duration=2;cmd_truncated=0;command_truncated=0\x07",
        ) else {
            panic!("expected CommandEnd");
        };
        assert_eq!(meta.duration_ms, None);
        assert!(
            meta.command_truncated,
            "ambiguous truncation disclosure must fail toward the safe fallback"
        );
    }

    #[test]
    fn osc133_truncation_disclosure_never_leaves_an_exact_command() {
        for disclosure in ["1", "true", "unknown"] {
            let packet =
                format!("\x1b]133;C;cmdline_url=partial-prefix;cmd_truncated={disclosure}\x07");
            let ParserEvent::CommandStart(meta) = only_event(packet.as_bytes()) else {
                panic!("expected CommandStart");
            };
            assert!(meta.command_truncated, "disclosure={disclosure}");
            assert_eq!(meta.command, None, "disclosure={disclosure}");
        }

        let ParserEvent::CommandStart(meta) =
            only_event(b"\x1b]133;C;cmdline_url=complete;cmd_truncated=false\x07")
        else {
            panic!("expected CommandStart");
        };
        assert!(!meta.command_truncated);
        assert_eq!(meta.command.as_deref(), Some("complete"));
    }

    #[test]
    fn osc133_truncation_aliases_follow_the_family_boolean_grammar() {
        for key in ["cmd_truncated", "command_truncated"] {
            for value in [" 0 ", " FALSE "] {
                let packet = format!("\x1b]133;C;cmdline_url=complete;{key}={value};id=jsh-2\x07");
                let ParserEvent::CommandStart(meta) = only_event(packet.as_bytes()) else {
                    panic!("expected CommandStart");
                };
                assert!(!meta.command_truncated, "key={key}, value={value:?}");
                assert_eq!(meta.command.as_deref(), Some("complete"), "key={key}");
                assert_eq!(meta.id.as_deref(), Some("jsh-2"), "key={key}");
            }

            for value in [" 1 ", " TRUE "] {
                let packet =
                    format!("\x1b]133;C;cmdline_url=partial-prefix;{key}={value};id=jsh-2\x07");
                let ParserEvent::CommandStart(meta) = only_event(packet.as_bytes()) else {
                    panic!("expected CommandStart");
                };
                assert!(meta.command_truncated, "key={key}, value={value:?}");
                assert_eq!(meta.command, None, "key={key}");
                assert_eq!(meta.id.as_deref(), Some("jsh-2"), "key={key}");
            }
        }

        let ParserEvent::CommandStart(meta) = only_event(
            b"\x1b]133;C;cmdline_url=partial-prefix;cmd_truncated=%20false%20;id=jsh-2\x07",
        ) else {
            panic!("expected CommandStart");
        };
        assert!(
            meta.command_truncated,
            "boolean fields are not percent-decoded"
        );
        assert_eq!(meta.command, None);
        assert_eq!(meta.id.as_deref(), Some("jsh-2"));
    }

    /// A missing or unparseable status is `None`, not success. It used to
    /// `unwrap_or(0)`, so a command of unknown outcome was reported as having
    /// succeeded -- and an exit-code badge showed a green 0.
    #[test]
    fn osc133_end_without_a_status_is_unknown_rather_than_zero() {
        assert_eq!(
            only_event(b"\x1b]133;D\x07"),
            ParserEvent::CommandEnd {
                exit: None,
                meta: CommandMeta::default()
            }
        );
        assert_eq!(
            only_event(b"\x1b]133;D;not-a-number\x07"),
            ParserEvent::CommandEnd {
                exit: None,
                meta: CommandMeta::default()
            }
        );
        // Metadata with no positional status must not be eaten as the status.
        assert_eq!(
            only_event(b"\x1b]133;D;id=jsh-4\x07"),
            ParserEvent::CommandEnd {
                exit: None,
                meta: CommandMeta {
                    id: Some("jsh-4".to_string()),
                    ..CommandMeta::default()
                }
            }
        );
        // A signal-terminated command reports 128+n, which must survive.
        assert_eq!(
            only_event(b"\x1b]133;D;143\x07"),
            ParserEvent::CommandEnd {
                exit: Some(143),
                meta: CommandMeta::default()
            }
        );
    }

    #[test]
    fn osc133_empty_cwd_is_absent_on_both_lifecycle_marks() {
        let ParserEvent::CommandStart(start) = only_event(b"\x1b]133;C;id=jsh-4;cwd_url=\x07")
        else {
            panic!("expected CommandStart");
        };
        assert_eq!(start.id.as_deref(), Some("jsh-4"));
        assert_eq!(start.cwd, None);

        let ParserEvent::CommandEnd { exit, meta } =
            only_event(b"\x1b]133;D;0;id=jsh-4;cwd_url=\x07")
        else {
            panic!("expected CommandEnd");
        };
        assert_eq!(exit, Some(0));
        assert_eq!(meta.id.as_deref(), Some("jsh-4"));
        assert_eq!(meta.cwd, None);
    }

    #[test]
    fn osc133_refuses_empty_or_jsh_invisible_command_metadata() {
        let ParserEvent::CommandStart(meta) = only_event(b"\x1b]133;C;id=jsh-4;cmdline_url=\x07")
        else {
            panic!("expected CommandStart");
        };
        assert_eq!(meta.id.as_deref(), Some("jsh-4"));
        assert_eq!(meta.command, None);

        for hidden in ['\u{fff9}', '\u{fffa}', '\u{fffb}'] {
            let packet = format!(
                "\x1b]133;C;id=jsh-4;cmdline_url=echo{hidden}hidden;cwd_url=/tmp/{hidden}hidden\x07"
            );
            let ParserEvent::CommandStart(meta) = only_event(packet.as_bytes()) else {
                panic!("expected CommandStart");
            };
            assert_eq!(meta.id.as_deref(), Some("jsh-4"));
            assert_eq!(meta.command, None, "accepted U+{:04X}", u32::from(hidden));
            assert_eq!(meta.cwd, None, "accepted U+{:04X}", u32::from(hidden));

            let packet = format!("\x1b]133;C;id=jsh{hidden}4;cmdline_url=true;cwd_url=/tmp\x07");
            let ParserEvent::CommandStart(meta) = only_event(packet.as_bytes()) else {
                panic!("expected CommandStart");
            };
            assert_eq!(meta.id, None, "accepted U+{:04X}", u32::from(hidden));
            assert_eq!(meta.command.as_deref(), Some("true"));
            assert_eq!(meta.cwd.as_deref(), Some("/tmp"));
        }
    }

    #[test]
    fn osc133_drops_a_field_it_cannot_decode_but_keeps_the_mark() {
        // Truncated escape, oversized value, and invalid UTF-8 each yield None
        // for that field only: half-decoded text becomes a path and a journal
        // key, so guessing is worse than admitting ignorance.
        let ParserEvent::CommandStart(meta) = only_event(b"\x1b]133;C;id=jsh-5;cwd_url=%2\x07")
        else {
            panic!("expected CommandStart");
        };
        assert_eq!(meta.id.as_deref(), Some("jsh-5"));
        assert_eq!(meta.cwd, None);

        let ParserEvent::CommandStart(meta) = only_event(b"\x1b]133;C;cwd_url=%FF%FE\x07") else {
            panic!("expected CommandStart");
        };
        assert_eq!(meta.cwd, None);

        let oversized = format!(
            "\x1b]133;C;cwd_url={}\x07",
            "x".repeat(MAX_OSC133_CWD_BYTES + 1)
        );
        let ParserEvent::CommandStart(meta) = only_event(oversized.as_bytes()) else {
            panic!("expected CommandStart");
        };
        assert_eq!(meta.cwd, None);
    }

    /// An id becomes a lookup key and is shown to the user, so a control
    /// character in it is refused outright rather than carried around.
    #[test]
    fn osc133_refuses_a_control_bearing_id() {
        let ParserEvent::CommandStart(meta) =
            only_event(b"\x1b]133;C;id=jsh%3A7%3B%1B%07;cwd_url=%2Ftmp\x07")
        else {
            panic!("expected CommandStart");
        };
        assert_eq!(meta.id, None);
        assert_eq!(meta.cwd.as_deref(), Some("/tmp"), "the mark still lands");
    }

    #[test]
    fn osc133_refuses_visual_spoofing_per_field_but_keeps_the_mark() {
        let ParserEvent::CommandStart(meta) = only_event(
            b"\x1b]133;C;id=jsh%E2%80%AE7;cmdline_url=echo%C2%A0hidden;cwd_url=%2Ftmp%E2%80%83dir;duration_ms=9\x07",
        ) else {
            panic!("expected CommandStart");
        };
        assert_eq!(meta.id, None);
        assert_eq!(meta.command, None);
        assert_eq!(meta.cwd, None);
        assert_eq!(meta.duration_ms, Some(9), "independent metadata survives");
    }

    #[test]
    fn osc133_accepts_the_key_aliases_ember_already_read() {
        let ParserEvent::CommandStart(meta) =
            only_event(b"\x1b]133;C;execution_id=x1;command=ls%20-la;cwd=%2Fsrv;duration=7\x07")
        else {
            panic!("expected CommandStart");
        };
        assert_eq!(meta.id.as_deref(), Some("x1"));
        assert_eq!(meta.command.as_deref(), Some("ls -la"));
        assert_eq!(meta.cwd.as_deref(), Some("/srv"));
        assert_eq!(meta.duration_ms, Some(7));
    }

    #[test]
    fn osc7_cwd_passes_through_to_vte() {
        let mut p = Parser::new();
        let mut events = Vec::new();
        p.feed(b"\x1b]7;file://host/home/me/dir\x07", &mut events);
        assert_eq!(
            collect_bytes(&events),
            b"\x1b]7;file://host/home/me/dir\x1b\\"
        );
    }

    #[test]
    fn osc7_and_title_updates_cannot_spoof_frontend_chrome() {
        let mut p = Parser::new();
        let mut events = Vec::new();
        p.feed(
            "\x1b]7;file://host/tmp/left\u{202e}right\x07".as_bytes(),
            &mut events,
        );
        p.feed(b"\x1b]7;file://host/tmp/left%0Aright\x07", &mut events);
        p.feed(
            b"\x1b]7;file://host/tmp/left%E2%80%AEright\x07",
            &mut events,
        );
        p.feed(b"\x1b]7;file://host/tmp/invalid%FFutf8\x07", &mut events);
        p.feed(b"\x1b]7;file://host/tmp/incomplete%2\x07", &mut events);
        p.feed("\x1b]2;build\u{00a0}done\x07".as_bytes(), &mut events);
        p.feed(
            "\x1b]7;file://host/tmp/left\u{fff9}right\x07".as_bytes(),
            &mut events,
        );
        p.feed(
            b"\x1b]7;file://host/tmp/left%EF%BF%B9right\x07",
            &mut events,
        );
        p.feed("\x1b]2;build\u{fffa}done\x07".as_bytes(), &mut events);
        assert!(collect_bytes(&events).is_empty());

        events.clear();
        p.feed(b"\x1b]2;safe title\x07", &mut events);
        assert_eq!(collect_bytes(&events), b"\x1b]2;safe title\x07");

        events.clear();
        let oversized_cwd = format!("\x1b]7;{}\x07", "x".repeat(MAX_OSC7_URI_BYTES + 1));
        p.feed(oversized_cwd.as_bytes(), &mut events);
        let oversized_title = format!("\x1b]2;{}\x07", "x".repeat(MAX_TITLE_BYTES + 1));
        p.feed(oversized_title.as_bytes(), &mut events);
        assert!(collect_bytes(&events).is_empty());
    }

    #[test]
    fn iterm_current_dir_requires_one_exact_unambiguous_path() {
        let mut parser = Parser::new();
        let mut events = Vec::new();

        parser.feed(
            "\x1b]1337;CurrentDir=/tmp/left\u{202e}right\x07".as_bytes(),
            &mut events,
        );
        for hidden in ['\u{fff9}', '\u{fffa}', '\u{fffb}'] {
            let frame = format!("\x1b]1337;CurrentDir=/tmp/left{hidden}right\x07");
            parser.feed(frame.as_bytes(), &mut events);
        }
        parser.feed(
            b"\x1b]1337;CurrentDir=/tmp/a;RemoteHost=evil\x07",
            &mut events,
        );
        parser.feed(b"\x1b]1337;CurrentDir=\x07", &mut events);
        let oversized = format!(
            "\x1b]1337;CurrentDir=/{}\x07",
            "x".repeat(MAX_OSC133_CWD_BYTES)
        );
        parser.feed(oversized.as_bytes(), &mut events);
        assert!(collect_bytes(&events).is_empty());

        events.clear();
        parser.feed(
            "\x1b]1337;CurrentDir=/home/u/my project/雪\x07".as_bytes(),
            &mut events,
        );
        assert_eq!(
            collect_bytes(&events),
            "\x1b]1337;CurrentDir=/home/u/my project/雪\x07".as_bytes()
        );
    }

    #[test]
    fn mouse_reporting_disabled_suppresses_wire_and_semantic_activation() {
        let mut p = Parser::with_config(ParserConfig {
            mouse_reporting: false,
            focus_reporting: true,
        });
        let mut events = Vec::new();
        p.feed(b"\x1b[?1000h", &mut events);
        assert!(collect_bytes(&events).is_empty());
        assert!(events.is_empty());
        assert_eq!(p.mouse_mode(), MouseMode::None);
    }

    #[test]
    fn osc_7770_emits_remote_session_id() {
        let mut p = Parser::new();
        let mut events = Vec::new();
        p.feed(b"\x1b]7770;home-main\x1b\\", &mut events);
        let id = events.iter().find_map(|e| match e {
            ParserEvent::RemoteSessionId(s) => Some(s.clone()),
            _ => None,
        });
        assert_eq!(id.as_deref(), Some("home-main"));
    }

    #[test]
    fn osc_7770_empty_payload_ignored() {
        let mut p = Parser::new();
        let mut events = Vec::new();
        p.feed(b"\x1b]7770;\x07", &mut events);
        assert!(events
            .iter()
            .all(|e| !matches!(e, ParserEvent::RemoteSessionId(_))));
    }

    #[test]
    fn osc_7770_rejects_non_jsh_identifiers() {
        for payload in [
            b"\x1b]7770;line\nbreak\x07".to_vec(),
            b"\x1b]7770;nul\0byte\x07".to_vec(),
            "\x1b]7770;left\u{202e}right\x07".as_bytes().to_vec(),
            "\x1b]7770;left\u{00a0}right\x07".as_bytes().to_vec(),
            b"\x1b]7770; leading-space\x07".to_vec(),
            b"\x1b]7770;contains.dot\x07".to_vec(),
        ] {
            let mut parser = Parser::new();
            let mut events = Vec::new();
            parser.feed(&payload, &mut events);
            assert!(events
                .iter()
                .all(|event| !matches!(event, ParserEvent::RemoteSessionId(_))));
        }

        let mut payload = b"\x1b]7770;".to_vec();
        payload.extend(std::iter::repeat_n(b'x', 129));
        payload.push(0x07);
        let mut parser = Parser::new();
        let mut events = Vec::new();
        parser.feed(&payload, &mut events);
        assert!(events
            .iter()
            .all(|event| !matches!(event, ParserEvent::RemoteSessionId(_))));
    }

    #[test]
    fn compound_private_modes_dispatch_alt_screen_in_stream_order() {
        let stream = b"before\x1b[?2004;1049;1006hframe\x1b[?1006;1049;2004lafter";
        let mut parser = Parser::new();
        let mut events = Vec::new();
        parser.feed(stream, &mut events);
        assert_eq!(
            events,
            vec![
                ParserEvent::Bytes(b"before".to_vec()),
                ParserEvent::DecsetMode {
                    mode: 2004,
                    set: true
                },
                ParserEvent::Bytes(b"\x1b[?2004h".to_vec()),
                ParserEvent::AltScreenEnter(1049),
                ParserEvent::DecsetMode {
                    mode: 1006,
                    set: true
                },
                ParserEvent::Bytes(b"\x1b[?1006hframe".to_vec()),
                ParserEvent::DecsetMode {
                    mode: 1006,
                    set: false
                },
                ParserEvent::Bytes(b"\x1b[?1006l".to_vec()),
                ParserEvent::AltScreenLeave(1049),
                ParserEvent::DecsetMode {
                    mode: 2004,
                    set: false
                },
                ParserEvent::Bytes(b"\x1b[?2004lafter".to_vec()),
            ]
        );
        assert!(!parser.bracketed_paste());
        for introducer in [b"\x1b[".as_slice(), b"\x9b", b"\xc2\x9b"] {
            for mode in [47, 1047, 1049] {
                let mut bytes = introducer.to_vec();
                bytes.extend_from_slice(format!("?0{mode};2004h").as_bytes());
                for split in 0..=bytes.len() {
                    let mut parser = Parser::new();
                    let mut events = Vec::new();
                    parser.feed(&bytes[..split], &mut events);
                    parser.feed(&bytes[split..], &mut events);
                    assert_eq!(
                        events
                            .iter()
                            .filter(|event| matches!(event, ParserEvent::AltScreenEnter(_)))
                            .count(),
                        1,
                        "mode={mode}, split={split}"
                    );
                    assert!(events.contains(&ParserEvent::AltScreenEnter(mode)));
                    assert!(parser.bracketed_paste());
                }
            }
        }
    }

    #[test]
    fn compound_private_modes_honor_mouse_and_focus_filters() {
        for final_byte in ['h', 'l'] {
            let mut parser = Parser::with_config(ParserConfig {
                mouse_reporting: false,
                focus_reporting: false,
            });
            let mut events = Vec::new();
            parser.feed(
                format!("\x1b[?01000;1004;2004;1006{final_byte}").as_bytes(),
                &mut events,
            );
            assert_eq!(
                collect_bytes(&events),
                format!("\x1b[?2004{final_byte}").as_bytes()
            );
            assert!(events.contains(&ParserEvent::DecsetMode {
                mode: 2004,
                set: final_byte == 'h'
            }));
            assert!(!events.iter().any(|event| matches!(
                event,
                ParserEvent::DecsetMode {
                    mode: 1000 | 1004 | 1006,
                    ..
                }
            )));
            assert_eq!(parser.mouse_mode(), MouseMode::None);
            assert!(!parser.focus_events());
        }
    }

    #[test]
    fn a_fresh_escape_interrupts_an_incomplete_csi_or_escape() {
        for prefix in [b"\x1b[12".as_slice(), b"\x1b"] {
            let mut stream = prefix.to_vec();
            stream.extend_from_slice(b"\x1bc\x1b]133;A\x07ready");
            for split in 0..=stream.len() {
                let mut parser = Parser::new();
                let mut events = Vec::new();
                parser.feed(b"\x1b[?2004h", &mut events);
                events.clear();
                parser.feed(&stream[..split], &mut events);
                parser.feed(&stream[split..], &mut events);
                assert!(
                    events.contains(&ParserEvent::HardReset),
                    "prefix={prefix:?}, split={split}"
                );
                assert!(events.contains(&ParserEvent::PromptStart));
                assert!(!parser.bracketed_paste());
            }
        }
    }

    #[test]
    fn can_and_sub_cancel_control_strings_and_csi_semantics() {
        for cancel in [0x18, 0x1a] {
            for prefix in [
                b"\x1b]133;A".as_slice(),
                b"\x1b_Gi=1",
                b"\x1bP$qm",
                b"\x1b^hidden",
                b"\x1bXhidden",
                b"\x1b[?2004",
            ] {
                let mut stream = prefix.to_vec();
                stream.push(cancel);
                stream.extend_from_slice(b"visible\x1b]133;B\x07");
                for split in 0..=stream.len() {
                    let mut parser = Parser::new();
                    let mut events = Vec::new();
                    parser.feed(&stream[..split], &mut events);
                    parser.feed(&stream[split..], &mut events);
                    assert!(
                        events.contains(&ParserEvent::PromptEnd),
                        "prefix={prefix:?}, cancel={cancel}, split={split}"
                    );
                    assert!(!events.iter().any(|event| matches!(
                        event,
                        ParserEvent::PromptStart
                            | ParserEvent::ApcSequence(_)
                            | ParserEvent::DecsetMode { .. }
                    )));
                    assert!(collect_bytes(&events).ends_with(b"visible"));
                    assert!(!parser.bracketed_paste());
                }
            }
        }
    }

    #[test]
    fn oversized_csi_is_discarded_without_bypassing_mode_filtering() {
        let mut stream = b"\x1b[?1000;".to_vec();
        stream.extend(std::iter::repeat_n(b'0', 5000));
        stream.extend_from_slice(b"hvisible");
        for split in [0, 1, 4096, 4097, 4500, stream.len()] {
            let mut parser = Parser::with_config(ParserConfig {
                mouse_reporting: false,
                focus_reporting: false,
            });
            let mut events = Vec::new();
            parser.feed(&stream[..split], &mut events);
            parser.feed(&stream[split..], &mut events);
            assert_eq!(collect_bytes(&events), b"visible", "split={split}");
            assert!(!events
                .iter()
                .any(|event| matches!(event, ParserEvent::DecsetMode { .. })));
        }
        for suffix in [b"\x18visible".as_slice(), b"\x1bcvisible"] {
            let mut parser = Parser::new();
            let mut events = Vec::new();
            parser.feed(&stream[..4500], &mut events);
            parser.feed(suffix, &mut events);
            assert!(collect_bytes(&events).ends_with(b"visible"));
            assert!(collect_bytes(&events).len() <= b"\x1bcvisible".len());
        }
    }

    #[test]
    fn omitted_or_overflowed_modes_cannot_hide_later_filtered_modes() {
        let mut parser = Parser::with_config(ParserConfig {
            mouse_reporting: false,
            focus_reporting: false,
        });
        let mut events = Vec::new();
        parser.feed(
            b"\x1b[?;9999999999999999999999;1000;1004;1006h",
            &mut events,
        );
        assert_eq!(collect_bytes(&events), b"\x1b[?0h\x1b[?4294967295h");
        assert!(!events.iter().any(|event| matches!(
            event,
            ParserEvent::DecsetMode {
                mode: 1000 | 1004 | 1006,
                ..
            }
        )));
    }

    #[test]
    fn embedded_c0_and_del_cannot_bypass_reporting_filters() {
        let mut parser = Parser::with_config(ParserConfig {
            mouse_reporting: false,
            focus_reporting: false,
        });
        let mut events = Vec::new();
        parser.feed(b"before\x1b[\r?10\x7f00;10\n04hafter", &mut events);
        assert_eq!(collect_bytes(&events), b"before\r\nafter");
        assert!(events
            .iter()
            .all(|event| matches!(event, ParserEvent::Bytes(_))));
        assert_eq!(parser.mouse_mode(), MouseMode::None);
        assert!(!parser.focus_events());
    }

    #[test]
    fn csi_c0_controls_preserve_bell_and_numeric_modes_in_both_configurations() {
        for enabled in [false, true] {
            let mut parser = Parser::with_config(ParserConfig {
                mouse_reporting: enabled,
                focus_reporting: enabled,
            });
            let mut events = Vec::new();
            let input = b"\x1b[?1000\x00h\x1b[?1000\x07;1006h\x1b[?1004\x7fh";
            parser.feed(input, &mut events);
            assert_eq!(parser.mouse_mode() == MouseMode::Normal, enabled);
            assert_eq!(parser.focus_events(), enabled);
            if enabled {
                assert_eq!(collect_bytes(&events), input);
            } else {
                assert_eq!(collect_bytes(&events), b"\x00\x07");
                assert!(events
                    .iter()
                    .all(|event| matches!(event, ParserEvent::Bytes(_))));
            }
        }
    }
}
